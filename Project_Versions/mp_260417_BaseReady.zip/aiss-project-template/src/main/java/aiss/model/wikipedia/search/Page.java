
package aiss.model.wikipedia.search;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "pageid", "ns", "title", "extract", "missing" })
public class Page {

	@JsonProperty("pageid")
	private Integer pageid;
	@JsonProperty("ns")
	private Integer ns;
	@JsonProperty("title")
	private String title;
	@JsonProperty("extract")
	private String extract;
	@JsonProperty("missing")
	private Boolean missing;

	@JsonProperty("pageid")
	public Integer getPageid() {
		return pageid;
	}

	@JsonProperty("pageid")
	public void setPageid(Integer pageid) {
		this.pageid = pageid;
	}

	@JsonProperty("ns")
	public Integer getNs() {
		return ns;
	}

	@JsonProperty("ns")
	public void setNs(Integer ns) {
		this.ns = ns;
	}

	@JsonProperty("title")
	public String getTitle() {
		return title;
	}

	@JsonProperty("title")
	public void setTitle(String title) {
		this.title = title;
	}

	@JsonProperty("extract")
	public String getExtract() {
		return extract;
	}

	@JsonProperty("extract")
	public void setExtract(String extract) {
		this.extract = extract;
	}

	@JsonProperty("missing")
	public Boolean getMissing() {
		return missing;
	}

	@JsonProperty("missing")
	public void setMissing(Boolean missing) {
		this.missing = missing;
	}

}