package aiss.controller;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import aiss.model.resources.SpotifyLibraryResource;
import aiss.model.resources.SpotifyResource;

/**
 * Servlet implementation class SpotifyAlbumLibraryController
 */
public class SpotifyAlbumLibraryController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private static final Logger log = Logger.getLogger(SpotifyResource.class.getName());

	public SpotifyAlbumLibraryController() {
		super();
		// TODO Auto-generated constructor stub
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		RequestDispatcher rd = null;
		String accessToken = (String) request.getSession().getAttribute("Spotify-token");
		String spotifyAlbumId;
		
		if (request.getParameter("spotifyAlbumId") != null) {

			spotifyAlbumId = request.getParameter("spotifyAlbumId");
			request.getSession().setAttribute("spotifyAlbumId", spotifyAlbumId);

		} else {

			spotifyAlbumId = (String) request.getSession().getAttribute("spotifyAlbumId");
		}

		if (accessToken != null && !"".equals(accessToken) && spotifyAlbumId != null && !"".equals(spotifyAlbumId)) {

			SpotifyLibraryResource SLResource = new SpotifyLibraryResource(accessToken);

			if (SLResource.addAlbum(spotifyAlbumId)) {
				log.log(Level.INFO, "Spotify album with id: " + spotifyAlbumId + " was added!");
				request.getSession().removeAttribute("spotifyAlbumId");
				rd = request.getRequestDispatcher("/AlbumController?spotifyAlbumId=" + spotifyAlbumId);
			} else {
				log.log(Level.SEVERE, "There was an error when adding " + spotifyAlbumId);

				Map<String, Object> objectErrorPool = new HashMap<String, Object>();

				objectErrorPool.put("spotifyAlbumId", spotifyAlbumId);
				request.setAttribute("objectsErrorKeySet", objectErrorPool.keySet());
				request.setAttribute("objectsErrorValues", objectErrorPool.values());

				rd = request.getRequestDispatcher("/error.jsp");
			}
		} else {

			log.log(Level.INFO, "Trying to access without a token");
			log.log(Level.INFO, "spotifyAlbumId: " + spotifyAlbumId);

			rd = spotifyAlbumId == null ? request.getRequestDispatcher("/error.jsp")
					: request.getRequestDispatcher("/AuthController/Spotify");
		}

		rd.forward(request, response);

	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
