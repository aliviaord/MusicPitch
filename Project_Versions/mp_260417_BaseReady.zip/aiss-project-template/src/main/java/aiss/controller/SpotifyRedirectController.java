package aiss.controller;

import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class SpotifyRedirectController
 */
public class SpotifyRedirectController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private static final Logger log = Logger.getLogger(SpotifyRedirectController.class.getName());

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public SpotifyRedirectController() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		RequestDispatcher rd = null;

		if (request.getSession().getAttribute("spotifyTrackId") != null) {
			rd = request.getRequestDispatcher("/SpotifyTrackLibraryController");
		} else if (request.getSession().getAttribute("spotifyAlbumId") != null) {
			rd = request.getRequestDispatcher("/SpotifyAlbumLibraryController");
		} else {
			log.log(Level.SEVERE,
					"An attemp to access to this page was made without coming from any of the Spotify Controllers...");
			rd = request.getRequestDispatcher("/error.jsp");
		}

		rd.forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
