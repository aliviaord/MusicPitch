package aiss.api.resources;

import java.net.URI;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.ResponseBuilder;
import javax.ws.rs.core.UriBuilder;
import javax.ws.rs.core.UriInfo;

import org.jboss.resteasy.spi.BadRequestException;
import org.jboss.resteasy.spi.NotFoundException;

import aiss.model.Comment;
import aiss.model.Profile;
import aiss.model.repository.CriticsRepository;
import aiss.model.repository.MapCriticsRepository;

@Path("/comments")
public class CommentResource {
	public static CommentResource _instance = null;
	CriticsRepository repository;

	private CommentResource() {
		repository = MapCriticsRepository.getInstance();
	}

	public static CommentResource getInstance() {
		if (_instance == null) {
			_instance = new CommentResource();
		}
		return _instance;
	}

	public List<Comment> filter(List<Comment> list, String word) {
		List<Comment> empty = new ArrayList<Comment>();
		for (Comment c : list) {
			if (c.getText().contains(word)) {
				empty.add(c);

			}
		}
		return empty;
	}

	public void order(List<Comment> list) {
		Comparator<Comment> c = Comparator.comparing(x -> x.getDate());
		Collections.sort(list, c);
	}

	public List<Comment> length(List<Comment> list, Integer index) {
		List<Comment> sublist = list.subList(0, index);
		return sublist;
	}

	@GET
	@Produces("application/json")
	public Collection<Comment> getAll(@QueryParam("contains") String word, 
			@QueryParam("order") String order,
			@QueryParam("offset") String offset,
			 @QueryParam("limit") String limit) {
		List<Comment> comments = new ArrayList<Comment>();
		for(Comment c:repository.getAllComments()){
			if(word == null || c.getText().contains(word) || word.equals("")){
				comments.add(c);
			}
			
			
		}
		
		if(order != null && order.equals(" date")){
			comments.sort(Comparator.comparing(x->x.getDate()));
		}
		if(order != null && order.equals("-date")){
			Comparator<Comment> c = Comparator.comparing(x->x.getDate());
			comments.sort(c.reversed());
		}
		Integer off = 0;
		Integer lim = comments.size();
		
		
		if(offset != null){
			off = new Integer(offset);
			if(off < 0 || off>comments.size()){
				off = 0;
			}
		}
		if(limit != null){
			lim = new Integer(limit);
			if(lim < 0 || lim+off>comments.size()){
				lim = comments.size();
			}
			
		}
		comments = comments.subList(off, lim+off>comments.size()?lim:lim+off);
		
		
		return comments;
		

		
	}

	@GET
	@Path("/{id}")
	@Produces("application/json")
	public Comment getComment(@PathParam("id") String commentId) {
		Comment comment = repository.getComment(commentId);
		if (comment == null) {
			throw new NotFoundException("The comment with id" + commentId + " was not found");
		}
		return comment;
	}

	@POST
	@Consumes("application/json")
	@Produces("application/json")
	public Response addComment(@Context UriInfo uriInfo, Comment c) {
		if (c == null) {
			throw new BadRequestException("The comment with id " + c.getId() + " can't be null");

		}
		repository.addComment(c);
		UriBuilder ub = uriInfo.getAbsolutePathBuilder().path(this.getClass(), "getComment");
		URI uri = ub.build(c.getId());
		ResponseBuilder resp = Response.created(uri);
		resp.entity(c);
		return resp.build();

	}

	@PUT
	@Consumes("application/json")
	public Response updateComment(Comment c) {
		Comment oldComment = repository.getComment(c.getId());
		if (oldComment == null) {
			throw new NotFoundException("The comment with id " + c.getId() + " was not found");
		}
		repository.updateComment(c);
		return Response.noContent().build();
	}

	@DELETE
	@Path("/{id}")
	public Response removeComment(@PathParam("id") String commentId) {
		Comment comment = repository.getComment(commentId);
		if (comment == null) {
			throw new NotFoundException("The comment with id " + commentId + " was not found");

		}
		repository.deleteComment(commentId);
		return Response.noContent().build();
	}

}
