package aiss.model.repository;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.google.appengine.repackaged.org.joda.time.LocalDateTime;

import aiss.model.Comment;
import aiss.model.Profile;

public class MapCriticsRepository implements CriticsRepository{
	
	Map<String, Comment> commentMap;
	Map<String, Profile> profileMap;
	private static MapCriticsRepository instance=null;
	private int index=0;
	
	public static MapCriticsRepository getInstance(){
		if(instance==null){
			instance = new MapCriticsRepository();
			instance.init();
		}
		
		return instance;
		
	}
	
	private void init() {
		commentMap = new HashMap<String, Comment>();
		profileMap = new HashMap<String, Profile>();
		//Create Comments
		Comment c1 = new Comment();
		c1.setUserName("josembell");
		c1.setText("Hello my name is Jose Manuel");
		c1.setDate("2017-02-16T20:44:53.950");
		addComment(c1);
		
		Comment c2 = new Comment();
		c2.setUserName("aliviaord");
		c2.setText("Hello my name is Alicia");
		c2.setDate("2015-01-16T20:44:53.950");
		addComment(c2);
		
		Comment c3 = new Comment();
		c3.setUserName("joancafom");
		c3.setText("Hello my name is Jose Antonio");
		c3.setDate("2020-11-16T20:44:53.950");
		addComment(c3);
		
		Comment c4 = new Comment();
		c4.setUserName("josedelpino");
		c4.setText("Hello my name is Jose Luis");
		c4.setDate("1998-01-16T20:44:53.950");
		addComment(c4);
		
		Comment c5 = new Comment();
		c5.setUserName("josembell");
		c5.setText("I love Spotify");
		c5.setDate("2013-04-16T20:44:53.950");
		addComment(c5);
		
		Comment c6 = new Comment();
		c6.setUserName("aliviaord");
		c6.setText("I love YouTube");
		c6.setDate("2015-12-16T20:44:53.950");
		addComment(c6);
		
		Comment c7 = new Comment();
		c7.setUserName("joancafom");
		c7.setText("I love Facebook");
		c7.setDate("2019-11-16T20:44:53.950");
		addComment(c7);
		
		Comment c8 = new Comment();
		c8.setUserName("josedelpino");
		c8.setText("I love Musixmatch");
		c8.setDate("2011-01-16T20:44:53.950");
		addComment(c8);
		
		
		//Create Profiles
		Profile josembell = new Profile();
		josembell.setUserName("josembell");
		josembell.setPassword("jose123");
		addProfile(josembell);
		
		Profile aliviaord = new Profile();
		aliviaord.setUserName("aliviaord");
		aliviaord.setPassword("alicia123");
		addProfile(aliviaord);
		
		Profile joancafom = new Profile();
		joancafom.setUserName("joancafom");
		joancafom.setPassword("joancafom123");
		addProfile(joancafom);
		
		Profile josedelpino = new Profile();
		josedelpino.setUserName("josedelpino");
		josedelpino.setPassword("josedelpino123");
		addProfile(josedelpino);
		
	}
	
	/* Comments */
	
	@Override
	public List<Comment> getAllComments() {
		List<Comment> comments = new ArrayList<Comment>(commentMap.values());
		return comments;
	}

	@Override
	public void addComment(Comment c) {
		String id = "c"+index++;
		if(profileMap.containsKey(c.getUserName())){
			profileMap.get(c.getUserName()).addComment(c);
		}
		else{
			Profile p = new Profile();
			p.setUserName(c.getUserName());
			p.setPassword(null);
			p.addComment(c);
			profileMap.put(p.getUserName(), p);
		}
		c.setId(id);
		if(c.getDate()!= null){
			c.setDate(c.getDate());
		}
		else{
			c.setDate(LocalDateTime.now().toString());
		}
		
		commentMap.put(id, c);
		
	}

	@Override
	public Comment getComment(String commentId) {
		return commentMap.get(commentId);
	}

	@Override
	public void deleteComment(String commentId) {
		commentMap.remove(commentId);
		
	}

	@Override
	public void updateComment(Comment c) {
		Comment comment = commentMap.get(c.getId());
		comment.setText(c.getText());
		if(c.getDate()!= null){
			c.setDate(c.getDate());
		}
		else{
			c.setDate(LocalDateTime.now().toString());
		}
		
	}
	
	/* Profiles */

	@Override
	public List<Profile> getAllProfiles() {
		List<Profile> profiles = new ArrayList<Profile>(profileMap.values());
		return profiles;
	}

	@Override
	public void addProfile(Profile p) {
		p.setComments(new ArrayList<Comment>());
		for(Comment e: commentMap.values()){
			if(e.getUserName().equals(p.getUserName())){
				p.addComment(e);
			}
		}
		profileMap.put(p.getUserName(), p);
		
	}

	@Override
	public void updateProfile(Profile p) {
		Profile profile = profileMap.get(p.getUserName());
		profile.setPassword(p.getPassword());
		
	}

	@Override
	public Profile getProfile(String userName) {
		return profileMap.get(userName);
	}

	@Override
	public void deleteProfile(String userName) {
		Set<Comment> comments = new HashSet<Comment>(commentMap.values());
		for(Comment e:comments){
			if(e.getUserName().equals(userName)){
				deleteComment(e.getId());
			}
		}
		profileMap.remove(userName);
		
	}

	

}
