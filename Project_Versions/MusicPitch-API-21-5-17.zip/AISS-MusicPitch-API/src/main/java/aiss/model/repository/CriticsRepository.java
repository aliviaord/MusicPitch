package aiss.model.repository;

import java.util.Collection;
import java.util.List;

import aiss.model.Comment;
import aiss.model.Profile;

public interface CriticsRepository {
	
	/*Comments*/
	public List<Comment> getAllComments();
	public void addComment(Comment c);
	public Comment getComment(String commentId);
	public void deleteComment(String commentId);
	public void updateComment(Comment c);
	
	/*Profiles*/
	public List<Profile> getAllProfiles();
	public void addProfile(Profile p);
	public void updateProfile(Profile p);
	public Profile getProfile(String username);
	public void deleteProfile(String username);
	
}
