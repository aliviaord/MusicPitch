package aiss.resourceTests;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

import java.io.UnsupportedEncodingException;

import org.junit.BeforeClass;
import org.junit.Test;

import aiss.model.resources.SpotifyResource;
import aiss.model.spotify.album.Album;
import aiss.model.spotify.artist.Artist;
import aiss.model.spotify.search.albums.Albums;
import aiss.model.spotify.search.albums.AlbumsSearch;
import aiss.model.spotify.search.artists.ArtistsSearch;
import aiss.model.spotify.search.tracks.TracksSearch;
import aiss.model.spotify.track.Track;

public class TestSpotifyResource {

	private static SpotifyResource spotifyResource;

	@BeforeClass
	public static void setUp() {
		spotifyResource = new SpotifyResource();
	}

	@Test(expected = NullPointerException.class)
	public void testSearchAlbumsNull() throws NullPointerException, UnsupportedEncodingException {
		String query = null;
		AlbumsSearch spotifyAlbums = spotifyResource.searchAlbums(query);
	}

	@Test(expected = NullPointerException.class)
	public void testSearchTracksNull() throws NullPointerException, UnsupportedEncodingException {
		String query = null;
		TracksSearch spotifyTracks = spotifyResource.searchTracks(query);
	}

	@Test(expected = NullPointerException.class)
	public void testSearchArtistsNull() throws NullPointerException, UnsupportedEncodingException {
		String query = null;
		ArtistsSearch spotifyArtists = spotifyResource.searchArtists(query);
	}

	@Test(expected = NullPointerException.class)
	public void testGetTrackNull() throws NullPointerException, UnsupportedEncodingException {
		String query = null;
		Track spotifyTrack = spotifyResource.getTrack(query);
	}

	@Test(expected = NullPointerException.class)
	public void testGetArtistNull() throws NullPointerException, UnsupportedEncodingException {
		String query = null;
		Artist spotifyArtist = spotifyResource.getArtist(query);
	}

	@Test(expected = NullPointerException.class)
	public void testGetArtistAlbumsNull() throws NullPointerException, UnsupportedEncodingException {
		String query = null;
		Albums spotifyArtistAlbums = spotifyResource.getArtistAlbums(query);
	}

	@Test(expected = NullPointerException.class)
	public void testGetAlbumNull() throws NullPointerException, UnsupportedEncodingException {
		String query = null;
		Album spotifyAlbum = spotifyResource.getAlbum(query);
	}

	@Test
	public void testSearchAlbumsEmpty() throws UnsupportedEncodingException {
		String query = "";
		AlbumsSearch spotifyAlbums = spotifyResource.searchAlbums(query);
		assertNull("The spotifyAlbums returned null.", spotifyAlbums);
	}

	@Test
	public void testSearchTracksEmpty() throws UnsupportedEncodingException {
		String query = "";
		TracksSearch spotifyTracks = spotifyResource.searchTracks(query);
		assertNull("The spotifyTracks returned null.", spotifyTracks);
	}

	@Test
	public void testSearchArtistsEmpty() throws UnsupportedEncodingException {
		String query = "";
		ArtistsSearch spotifyArtists = spotifyResource.searchArtists(query);
		assertNull("The spotifyArtists returned null.", spotifyArtists);
	}

	@Test
	public void testGetTrackEmpty() throws NullPointerException, UnsupportedEncodingException {
		String query = "";
		Track spotifyTrack = spotifyResource.getTrack(query);
		assertNull("The spotifyTrack returned null.", spotifyTrack);
	}

	@Test
	public void testGetArtistEmpty() throws NullPointerException, UnsupportedEncodingException {
		String query = "";
		Artist spotifyArtist = spotifyResource.getArtist(query);
		assertNull("The spotifyArtist returned null.", spotifyArtist);
	}

	@Test
	public void testGetArtistAlbumsEmpty() throws NullPointerException, UnsupportedEncodingException {
		String query = "";
		Albums spotifyArtistAlbums = spotifyResource.getArtistAlbums(query);
		assertNull("The spotifyArtistAlbums returned null.", spotifyArtistAlbums);
	}

	@Test
	public void testGetAlbumEmpty() throws NullPointerException, UnsupportedEncodingException {
		String query = "";
		Album spotifyAlbum = spotifyResource.getAlbum(query);
		assertNull("The spotifyAlbum returned null.", spotifyAlbum);
	}

	@Test
	public void testSearchAlbumsFound() throws UnsupportedEncodingException {
		String query = "The Fame";
		AlbumsSearch spotifyAlbums = spotifyResource.searchAlbums(query);
		assertNotNull("The spotifyAlbums returned null", spotifyAlbums);
		assertTrue("There must be at least 1 album returned in spotifyAlbums.",
				spotifyAlbums.getAlbums().getItems().size() > 0);
		assertEquals("The artist of the most important album called 'The Fame' must be 'Lady Gaga'.",
				spotifyAlbums.getAlbums().getItems().get(0).getArtists().get(0).getName(), "Lady Gaga");
	}

	@Test
	public void testSearchTracksFound() throws UnsupportedEncodingException {
		String query = "Judas";
		TracksSearch spotifyTracks = spotifyResource.searchTracks(query);
		assertNotNull("The spotifyTracks returned null", spotifyTracks);
		assertTrue("There must be at least 1 track returned in spotifyTracks.",
				spotifyTracks.getTracks().getItems().size() > 0);
		assertEquals("The album of the most important track called 'Judas' must be 'Born This Way'.",
				spotifyTracks.getTracks().getItems().get(0).getAlbum().getName(), "Born This Way");
	}

	@Test
	public void testSearchArtistsFound() throws UnsupportedEncodingException {
		String query = "Sia";
		ArtistsSearch spotifyArtists = spotifyResource.searchArtists(query);
		assertNotNull("The spotifyArtists returned null", spotifyArtists);
		assertTrue("There must be at least 1 artist returned in spotifyArtists.",
				spotifyArtists.getArtists().getItems().size() > 0);
		assertEquals("The most important artist called 'Sia' must have the ID '5WUlDfRSoLAfcVSX1WnrxN'.",
				spotifyArtists.getArtists().getItems().get(0).getId(), "5WUlDfRSoLAfcVSX1WnrxN");
	}

	@Test
	public void testGetTrackFound() throws UnsupportedEncodingException {
		String query = "0QkWikH5Z3U0f79T9iuF6c";
		Track spotifyTrack = spotifyResource.getTrack(query);
		assertNotNull("The spotifyTrack returned null", spotifyTrack);
		assertEquals("The artist of this song must be 'Lady Gaga'.", spotifyTrack.getArtists().get(0).getName(),
				"Lady Gaga");
	}

	@Test
	public void testGetArtistFound() throws UnsupportedEncodingException {
		String query = "5WUlDfRSoLAfcVSX1WnrxN";
		Artist spotifyArtist = spotifyResource.getArtist(query);
		assertNotNull("The spotifyArtist returned null", spotifyArtist);
		assertEquals("The artist must have 'pop' as its least important genre.", spotifyArtist.getGenres().get(2),
				"pop");
	}

	@Test
	public void testGetArtistAlbumsFound() throws UnsupportedEncodingException {
		String query = "1HY2Jd0NmPuamShAr6KMms";
		Albums spotifyArtistAlbums = spotifyResource.getArtistAlbums(query);
		assertNotNull("The spotifyArtistAlbums returned null", spotifyArtistAlbums);
		assertEquals("The first album from the artist must be 'Joanne (Deluxe)'.",
				spotifyArtistAlbums.getItems().get(0).getName(), "Joanne (Deluxe)");
	}

	@Test
	public void testGetAlbumFound() throws UnsupportedEncodingException {
		String query = "4yHr095BMG5I3IRH4ToE5l";
		Album spotifyAlbum = spotifyResource.getAlbum(query);
		assertNotNull("The spotifyAlbum returned null", spotifyAlbum);
		assertEquals("The artist of this album must be 'Lady Gaga'.", spotifyAlbum.getArtists().get(0).getName(),
				"Lady Gaga");
	}

}
