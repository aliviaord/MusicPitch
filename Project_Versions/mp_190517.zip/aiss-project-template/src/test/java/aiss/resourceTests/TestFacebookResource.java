package aiss.resourceTests;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

import java.io.UnsupportedEncodingException;

import org.junit.BeforeClass;
import org.junit.Test;

import aiss.model.facebook.posts.Posts;
import aiss.model.facebook.search.pages.PagesSearch;
import aiss.model.resources.FacebookResource;

public class TestFacebookResource {

	private static final String access_token = "EAAGfqb6DxZCgBAE5cBKI00vhRSzo7P84TASSF9M0X4pf6jMgjNw6kwR6CXoZBzZAFLYZAM6Oj92o3nW66It2gEznIE9Qq87pBsTdLL4KKVfnITaEXKwhiRPdfE4ShZAjTS7KwMR4Hii2JN5RrtwbwmA9y4H0SBQZAGS620SceOHaIdb2qjFWFZCg76eUXg7E24ZD";
	private static FacebookResource facebookResource;

	@BeforeClass
	public static void setUp() {
		facebookResource = new FacebookResource(access_token);
	}

	@Test(expected = NullPointerException.class)
	public void testSearchPagesNull() throws NullPointerException, UnsupportedEncodingException {
		String query = null;
		PagesSearch facebookPages = facebookResource.searchPages(query);
	}

	@Test
	public void testSearchPagesEmpty() throws UnsupportedEncodingException {
		String query = "";
		PagesSearch facebookPages = facebookResource.searchPages(query);
		assertNull("The facebookPages returned null.", facebookPages);
	}

	@Test
	public void testSearchPagesFound() throws UnsupportedEncodingException {
		String query = "Lady Gaga";
		PagesSearch facebookPages = facebookResource.searchPages(query);
		assertNotNull("The facebookPages didn't return null", facebookPages);
		assertTrue("There must be at least 1 page returned in facebookPages.", facebookPages.getData().size() > 0);
		assertEquals("The first page returned must be 'Lady Gaga'.", facebookPages.getData().get(0).getName(),
				"Lady Gaga");
	}

	@Test(expected = NullPointerException.class)
	public void testGetPostsNull() throws NullPointerException, UnsupportedEncodingException {
		String query = null;
		Posts facebookPosts = facebookResource.getPosts(query);
	}

	@Test
	public void testGetPostsEmpty() throws NullPointerException, UnsupportedEncodingException {
		String query = "";
		Posts facebookPosts = facebookResource.getPosts(query);
		assertNull("The facebookPosts returned null.", facebookPosts);
	}
}
