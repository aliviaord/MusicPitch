package aiss.resourceTests;

import static org.junit.Assert.assertTrue;

import java.io.UnsupportedEncodingException;

import org.junit.BeforeClass;
import org.junit.Test;

import aiss.model.resources.FacebookPostResource;

public class TestFacebookPostResource {

	private static final String access_token = "EAAGfqb6DxZCgBAE5cBKI00vhRSzo7P84TASSF9M0X4pf6jMgjNw6kwR6CXoZBzZAFLYZAM6Oj92o3nW66It2gEznIE9Qq87pBsTdLL4KKVfnITaEXKwhiRPdfE4ShZAjTS7KwMR4Hii2JN5RrtwbwmA9y4H0SBQZAGS620SceOHaIdb2qjFWFZCg76eUXg7E24ZD";
	private static FacebookPostResource facebookPostResource;

	@BeforeClass
	public static void setUp() {
		facebookPostResource = new FacebookPostResource(access_token);
	}

	@Test(expected = NullPointerException.class)
	public void testPostNull() throws NullPointerException, UnsupportedEncodingException {
		String query = null;
		facebookPostResource.publishPost(query);
	}

	
	public void testPost() {
		String query = "This is a JUnit test.";
		Boolean postPublished = facebookPostResource.publishPost(query);
		assertTrue("The post should have been posted.", postPublished);
	}

}
