package aiss.resourceTests;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

import java.io.UnsupportedEncodingException;

import org.junit.BeforeClass;
import org.junit.Test;

import aiss.model.resources.SongkickResource;
import aiss.model.songkick.search.ConcertsSearch;

public class TestSongkickResource {
	
private static SongkickResource songkickResource;
	
	@BeforeClass
	public static void setUp(){
		songkickResource = new SongkickResource();
	}
	
	@Test (expected = NullPointerException.class)
	public void testSearchNull() throws NullPointerException, UnsupportedEncodingException{
		String query = null;
		ConcertsSearch songkickConcerts = songkickResource.searchConcerts(query);
	}
	
	@Test
	public void testSearchEmpty() throws UnsupportedEncodingException{
		String query = "";
		ConcertsSearch songkickConcerts = songkickResource.searchConcerts(query);
		assertNotNull("The songkickConcerts returned null",songkickConcerts);
		assertEquals("The status property from songkickConcerts should be 'ok'",songkickConcerts.getResultsPage().getStatus(), "ok");
		assertEquals("The songkickConcerts totalEntries should be 0",songkickConcerts.getResultsPage().getTotalEntries(), new Integer(0));
		assertNull("The songkickConcerts results for an empty query should be null",songkickConcerts.getResultsPage().getResults().getEvent());
	}

	
	@Test
	public void testSearchPageFound() throws UnsupportedEncodingException{
		String query = "Lady Gaga";
		ConcertsSearch songkickConcerts = songkickResource.searchConcerts(query);
		assertNotNull("The songkickConcerts returned null",songkickConcerts);
		assertEquals("The status property from songkickConcerts should be 'ok'",songkickConcerts.getResultsPage().getStatus(), "ok");
		assertTrue("The songkickConcerts totalEntries should be greater than 0", songkickConcerts.getResultsPage().getTotalEntries() > 0);
		assertTrue("The songkickConcerts results for an empty query should be null",songkickConcerts.getResultsPage().getResults().getEvent().size() > 0);
		for(int i = 0; i<songkickConcerts.getResultsPage().getResults().getEvent().size(); i++){
			assertEquals("The status property from the songkickConcerts events should be 'ok'",songkickConcerts.getResultsPage().getResults().getEvent().get(i).getStatus(), "ok");
		}
		
	}

}
