package aiss.resourceTests;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import java.io.UnsupportedEncodingException;

import org.junit.BeforeClass;
import org.junit.Test;

import aiss.model.musixmatch.lyrics.Lyrics;
import aiss.model.resources.MusixMatchResource;

public class TestMusixMatchResource {
	
	private static MusixMatchResource musixMatchResource;

	@BeforeClass
	public static void setUp() {
		musixMatchResource = new MusixMatchResource();
	}

	@Test(expected = NullPointerException.class)
	public void testSearchNull() throws NullPointerException, UnsupportedEncodingException {
		String queryTrack = null;
		String queryArtist = null;
		Lyrics musixMatchLyrics = musixMatchResource.getLyrics(queryTrack, queryArtist);
	}
	
	@Test(expected = NullPointerException.class)
	public void testSearchTrackNull() throws NullPointerException, UnsupportedEncodingException {
		String queryTrack = null;
		String queryArtist = "";
		Lyrics musixMatchLyrics = musixMatchResource.getLyrics(queryTrack, queryArtist);
	}
	
	@Test(expected = NullPointerException.class)
	public void testSearchArtistNull() throws NullPointerException, UnsupportedEncodingException {
		String queryTrack = "";
		String queryArtist = null;
		Lyrics musixMatchLyrics = musixMatchResource.getLyrics(queryTrack, queryArtist);
	}

	@Test
	public void testSearchEmpty() throws UnsupportedEncodingException {
		String queryTrack = "";
		String queryArtist = "";
		Lyrics musixMatchLyrics = musixMatchResource.getLyrics(queryTrack, queryArtist);
		assertNotNull("The musixMatchLyrics returned null", musixMatchLyrics);
		assertEquals("The lyrics from musixMatchLyrics be 'Lyrics aren't available for this track'",
				musixMatchLyrics.getLyrics(), "Lyrics aren't available for this track");
	}

	@Test
	public void testSearchPageFound() throws UnsupportedEncodingException {
		
		String queryTrack = "Occidentali's Karma";
		String queryArtist = "Francesco Gabanni";
		Lyrics musixMatchLyrics = musixMatchResource.getLyrics(queryTrack, queryArtist);
		assertNotNull("The musixMatchLyrics returned null", musixMatchLyrics);
		assertNotEquals("The lyrics from musixMatchLyrics be 'Lyrics aren't available for this track'",
				musixMatchLyrics.getLyrics(), "Lyrics aren't available for this track");
		assertTrue("The lyrics from Francesco Gabanni - Occidentali's Karma should include 'Essere o dover essere' ", musixMatchLyrics.getLyrics().contains("Essere o dover essere"));

	}
}
