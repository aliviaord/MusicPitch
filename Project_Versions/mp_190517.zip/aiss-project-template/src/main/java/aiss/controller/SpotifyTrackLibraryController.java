package aiss.controller;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import aiss.model.resources.SpotifyLibraryResource;
import aiss.model.resources.SpotifyResource;

/**
 * Servlet implementation class SpotifyLibraryController
 */
public class SpotifyTrackLibraryController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private static final Logger log = Logger.getLogger(SpotifyResource.class.getName());
	
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public SpotifyTrackLibraryController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		RequestDispatcher rd = null;
		String accessToken = (String) request.getSession().getAttribute("Spotify-token");
		String spotifyTrackId;
		
		if (request.getParameter("spotifyTrackId") != null) {

			spotifyTrackId = request.getParameter("spotifyTrackId");
			request.getSession().setAttribute("spotifyTrackId", spotifyTrackId);

		} else {

			spotifyTrackId = (String) request.getSession().getAttribute("spotifyTrackId");
		}
		
		if(accessToken!=null && !"".equals(accessToken) && spotifyTrackId !=null && !"".equals(spotifyTrackId)){

				SpotifyLibraryResource SLResource = new SpotifyLibraryResource(accessToken);
				if(SLResource.addTrack(spotifyTrackId)){
					log.log(Level.INFO, "Spotify track with id: " + spotifyTrackId + " was added!");
					request.getSession().removeAttribute("spotifyTrackId");
					rd = request.getRequestDispatcher("/TrackController?spotifyTrackId=" + spotifyTrackId);
				}else{
					log.log(Level.SEVERE, "There was an error when adding " + spotifyTrackId);
					
					Map<String, Object> objectErrorPool = new HashMap<String, Object>();

					objectErrorPool.put("spotifyTrackId", spotifyTrackId);
					request.setAttribute("objectsErrorKeySet", objectErrorPool.keySet());
					request.setAttribute("objectsErrorValues", objectErrorPool.values());
					
					rd = request.getRequestDispatcher("/error.jsp");
				}
		}
		else{
			
			log.log(Level.INFO, "Trying to access without a token");
			log.log(Level.INFO, "spotifyTrackId: " + spotifyTrackId);

			rd = spotifyTrackId == null ? request.getRequestDispatcher("/error.jsp")
					: request.getRequestDispatcher("/AuthController/Spotify");
		}
		
		rd.forward(request, response);
		
	
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
