package aiss.controller;

import java.io.IOException;
import java.util.logging.Logger;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import aiss.model.resources.FacebookPostResource;

/**
 * Servlet implementation class FacebookShareLyricsController
 */
public class FacebookShareLyricsController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private static final Logger log = Logger.getLogger(FacebookShareLyricsController.class.getName());

	public FacebookShareLyricsController() {
		super();

	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		String lyricsQuote = null;
		String accessToken = (String) request.getSession().getAttribute("Facebook-token");

		if (request.getParameter("lyricsQuote") != null) {

			lyricsQuote = request.getParameter("lyricsQuote");
			request.getSession().setAttribute("lyricsQuote", lyricsQuote);

		} else {

			lyricsQuote = (String) request.getSession().getAttribute("lyricsQuote");
		}

		// We save the value for later in session
		if (request.getParameter("spotifyTrackId") != null) {
			request.getSession().setAttribute("spotifyTrackId", request.getParameter("spotifyTrackId"));
		}

		if (accessToken != null && !"".equals(accessToken)) {

			FacebookPostResource fbResource = new FacebookPostResource(accessToken);
			fbResource.publishPost(lyricsQuote);
			String spotifyTrackId = request.getSession().getAttribute("spotifyTrackId") == null ? "" : (String) request.getSession().getAttribute("spotifyTrackId");
			request.getSession().removeAttribute("spotifyTrackId");
			request.getRequestDispatcher("/TrackController?spotifyTrackId=" + spotifyTrackId).forward(request, response);

		} else {

			log.info("Trying to acces to Facebook without an acces token, redirecting to OAuth servlet");
			request.getRequestDispatcher("/AuthController/Facebook").forward(request, response);
		}

	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}

}
