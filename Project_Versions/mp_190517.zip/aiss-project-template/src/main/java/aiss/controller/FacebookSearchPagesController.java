package aiss.controller;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import aiss.model.facebook.search.pages.PagesSearch;
import aiss.model.resources.FacebookResource;

/**
 * Servlet implementation class FacebookSearchUserController
 */
public class FacebookSearchPagesController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private static final Logger log = Logger.getLogger(FacebookSearchPagesController.class.getName());

	public FacebookSearchPagesController() {
		super();
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		RequestDispatcher rd = null;
		String fbAccessToken = (String) request.getSession().getAttribute("Facebook-token");
		String fbQuery;

		// We choose the right value for fbQuery as we may come from
		// a) A view, and so we'll have a PARAMETER, and we'll save it for later
		// in session
		// b) Obtaining the token from the FB server and we'll have the query
		// saved in the session
		if (request.getParameter("fbQuery") != null) {

			fbQuery = request.getParameter("fbQuery");
			request.getSession().setAttribute("fbQuery", fbQuery);

		} else {

			fbQuery = (String) request.getSession().getAttribute("fbQuery");
		}

		// We save the value for later in session
		if (request.getParameter("spotifyArtistId") != null) {
			request.getSession().setAttribute("spotifyArtistId", request.getParameter("spotifyArtistId"));
		}

		if (fbAccessToken != null && fbAccessToken != "" && fbQuery != null) {

			log.log(Level.INFO, "There exists a token");
			log.log(Level.INFO, "Token: " + fbAccessToken);

			FacebookResource fbResource = new FacebookResource(fbAccessToken);

			log.log(Level.INFO, "Facebook Query" + fbQuery);

			PagesSearch fbPages = fbResource.searchPages(fbQuery);

			if (fbPages != null) {

				request.getSession().removeAttribute("fbQuery");
				request.setAttribute("fbPageId", fbPages.getData().get(0).getId());
				rd = request.getRequestDispatcher("/FacebookPostsController");

			} else {

				log.log(Level.SEVERE, "There was an error when retrieving the FB Pages. fbPages Object: " + fbPages);

				Map<String, Object> objectErrorPool = new HashMap<String, Object>();

				objectErrorPool.put("fbPages", fbPages);
				request.setAttribute("objectsErrorKeySet", objectErrorPool.keySet());
				request.setAttribute("objectsErrorValues", objectErrorPool.values());

				rd = request.getRequestDispatcher("/error.jsp");
			}

		} else {

			log.log(Level.INFO, "Trying to access without a token");
			log.log(Level.INFO, "fbQuery: " + fbQuery);

			rd = fbQuery == null ? request.getRequestDispatcher("/error.jsp")
					: request.getRequestDispatcher("/AuthController/Facebook");
		}

		rd.forward(request, response);

	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
