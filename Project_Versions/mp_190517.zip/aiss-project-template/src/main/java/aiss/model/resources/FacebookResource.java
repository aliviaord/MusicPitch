package aiss.model.resources;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.restlet.resource.ClientResource;
import org.restlet.resource.ResourceException;

import aiss.model.facebook.posts.Posts;
import aiss.model.facebook.search.pages.PagesSearch;

public class FacebookResource {

	private static final Logger log = Logger.getLogger(FacebookResource.class.getName());
	private String accessToken = null;
	private String uri = "https://graph.facebook.com/v2.9/";
	//private String uriPages = "https://graph.facebook.com/v2.9/search?";

	public FacebookResource(String accessToken) {
		this.accessToken = accessToken;
	}

	public PagesSearch searchPages(String query) throws UnsupportedEncodingException {
		
		PagesSearch res = null;
		ClientResource cr = null;
	
		try {
			String queryEncoded = URLEncoder.encode(query, "UTF-8");
			cr = new ClientResource(uri + "search?access_token=" + accessToken + "&q=" + queryEncoded + "&type=page");
			res = cr.get(PagesSearch.class);
		} catch (ResourceException e) {
			log.log(Level.SEVERE, "There was an error when searching for pages");
		}

		
		try {
			System.out.println(cr.get().getText());
		} catch (ResourceException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return res;
	}
	
	public Posts getPosts(String query) throws UnsupportedEncodingException {
		
		Posts res = null;
		ClientResource cr = null;

		try {
			String queryEncoded = URLEncoder.encode(query, "UTF-8");
			cr = new ClientResource(uri + queryEncoded + "/posts?access_token=" + accessToken);
			res = cr.get(Posts.class);
		} catch (ResourceException e) {
			log.log(Level.SEVERE, "There was an error when retrieving posts");
		}

		return res;
	}
}
