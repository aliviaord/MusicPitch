package aiss.model.resources;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.restlet.resource.ClientResource;
import org.restlet.resource.ResourceException;

import aiss.model.songkick.search.ConcertsSearch;

public class SongkickResource {

	private static final Logger log = Logger.getLogger(SongkickResource.class.getName());
	private static final String key = "Aex0UZ56YGje3eEs";

	public ConcertsSearch searchConcerts(String query) throws UnsupportedEncodingException {

		ConcertsSearch res = null;
		ClientResource cr = null;

		try {
			String queryEncoded = URLEncoder.encode(query, "UTF-8");
			cr = new ClientResource("http://api.songkick.com/api/3.0/events.json?apikey=" + key + "&artist_name=" + queryEncoded);
			res = cr.get(ConcertsSearch.class);
		} catch (ResourceException e) {
			log.log(Level.SEVERE, "Error when retrieving SongKick concerts " + cr.getResponse().getStatus());
		}

		return res;

	}

}
