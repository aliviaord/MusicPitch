package aiss.model.resources;

import java.util.logging.Level;
import java.util.logging.Logger;

import org.restlet.resource.ClientResource;
import org.restlet.resource.ResourceException;

public class SpotifyLibraryResource {
	private String access_token;
	private static final Logger log = Logger.getLogger(SpotifyLibraryResource.class.getName());

	public SpotifyLibraryResource(String access_token) {
		this.access_token = access_token;
	}

	public boolean addTrack(String spotifyTrackId){

		ClientResource cr = null;
		boolean result = false;

		try {
			cr = new ClientResource("https://api.spotify.com/v1/me/tracks?access_token=" + access_token + "&ids=" + spotifyTrackId);
			cr.put("");
			System.out.println("The ClientResource is " + cr);
			result = true;
			
		} catch (ResourceException e) {
			log.log(Level.SEVERE, "Error when adding Track to the Spotify account: " + cr.getResponse().getStatus());
		}
		return result;
	}

	public boolean addAlbum(String spotifyAlbumId){

		ClientResource cr = null;
		boolean result = false;

		try {
			cr = new ClientResource("https://api.spotify.com/v1/me/albums?access_token=" + access_token + "&ids=" + spotifyAlbumId);
			cr.put("");
			result = true;
		} catch (ResourceException re) {
			log.log(Level.SEVERE, "Error when adding Album to the Spotify account: " + cr.getResponse().getStatus());
		}

		return result;
	}

}
