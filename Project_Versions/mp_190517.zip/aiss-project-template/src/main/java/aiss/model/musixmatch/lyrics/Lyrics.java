package aiss.model.musixmatch.lyrics;

import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Lyrics {

	private static final Logger log = Logger.getLogger(Lyrics.class.getName());
	private static final Pattern p = Pattern.compile("\"lyrics_body.+?Commercial use");
	private String lyrics;
	
	public Lyrics(String rawText) {

		Matcher m = p.matcher(rawText);
		String lyrics = "Lyrics aren't available for this track";
		
		if(m.find()){
			
			lyrics = m.group();
			lyrics = lyrics.replace("\"lyrics_body\":\"", "");
			lyrics = lyrics.replace("\\n", "\n");
			lyrics = lyrics.concat(" *******");
		}else{
			log.log(Level.FINE,"There are no lyrics");
			log.log(Level.FINE,"Received raw text: " + rawText);
		}
		
		this.lyrics = lyrics;
		
	}

	public String getLyrics() {
		return lyrics;
	}

	public void setLyrics(String lyrics) {
		this.lyrics = lyrics;
	}

}
