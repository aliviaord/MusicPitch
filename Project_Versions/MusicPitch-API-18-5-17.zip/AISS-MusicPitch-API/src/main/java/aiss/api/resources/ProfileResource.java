package aiss.api.resources;

import java.net.URI;
import java.util.Collection;
import java.util.Comparator;
import java.util.LinkedList;
import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.UriBuilder;
import javax.ws.rs.core.UriInfo;
import javax.ws.rs.core.Response.ResponseBuilder;

import org.jboss.resteasy.spi.BadRequestException;
import org.jboss.resteasy.spi.NotFoundException;

import aiss.model.Comment;
import aiss.model.Profile;
import aiss.model.repository.CriticsRepository;
import aiss.model.repository.MapCriticsRepository;

@Path("/profiles")
public class ProfileResource{
	public static ProfileResource _instance=null;
	CriticsRepository repository; 
	
	private ProfileResource(){
		repository=MapCriticsRepository.getInstance(); 
	}
	
	public static ProfileResource getInstance(){
		if(_instance==null){
			_instance=new ProfileResource();
		}
		return _instance;
	}
	
	@GET
	@Produces("application/json")
	public Collection<Profile> getAllProfiles(@QueryParam("filter") String username,
			@QueryParam("order") String order,
			 @QueryParam("length") String length){
		List<Profile> profiles = new LinkedList<Profile>();
		for(Profile p:repository.getAllProfiles()){
			if(username == null || p.getUserName().equals(username) || username.equals("")){
				profiles.add(p);
			}
			
			
		}
		if(order != null && order.equals("true")){
			profiles.sort(Comparator.comparing(x->x.getUserName()));
		}
		if(length != null && new Integer(length)>0){
			if(!(new Integer(length)>profiles.size())){
				profiles = profiles.subList(0, Integer.parseInt(length));
			}
		}
		
		
		return profiles;
	}
	
	@POST
	@Consumes("application/json")
	@Produces("application/json")
	public Response addProfile(@Context UriInfo uriInfo, Profile p){
		if(p.getPassword() == null || p.getUserName()== null){
			throw new BadRequestException("The profile with username: "+p.getUserName()+" can't be null");
			
		}
		repository.addProfile(p);
		UriBuilder ub = uriInfo.getAbsolutePathBuilder().path(this.getClass(), "getProfile");
		URI uri = ub.build(p.getUserName());
		ResponseBuilder resp = Response.created(uri);
		resp.entity(p);
		return resp.build();
	
	}
	
	@GET
	@Path("/{userName}")
	@Produces("application/json")
	public Profile getProfile(@PathParam("userName") String userName){
		Profile profile = repository.getProfile(userName);
		if(profile == null){
			throw new NotFoundException("The profile with username: "+userName+" wasn't found");
		}
		return profile;
	}
	
	@PUT
	@Consumes("application/json")
	public Response updateProfile(Profile p){
		Profile oldProfile = repository.getProfile(p.getUserName());
		if(oldProfile == null){
			throw new NotFoundException("The profile with username: "+p.getUserName()+" was not found");
		}
		repository.updateProfile(p);
		return Response.noContent().build();
		
	}
	
	@DELETE
	@Path("/{id}")
	public Response removeProfile(@PathParam("id") String userName){
		Profile profile = repository.getProfile(userName);
		if(profile == null){
			throw new NotFoundException("The profile with username: "+profile.getUserName()+" was not found");
			
		}
		repository.deleteProfile(userName);
		return Response.noContent().build();
	}
	
	
	
}
