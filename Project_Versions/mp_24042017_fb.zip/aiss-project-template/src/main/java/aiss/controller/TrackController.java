package aiss.controller;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import aiss.model.resources.SpotifyResource;
import aiss.model.resources.YouTubeResource;
import aiss.model.spotify.track.Track;
import aiss.model.youtube.search.VideosSearch;

/**
 * Servlet implementation class SongController
 */
public class TrackController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	private static final Logger log = Logger.getLogger(TrackController.class.getName());
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public TrackController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		String spotifyTrackId = request.getParameter("spotifyTrackId");
		RequestDispatcher rd = null;
		Map<String, Object> objectErrorPool = null;
		
		// Retrieving a song given its id
		log.log(Level.FINE, "Retrieving the Song with the ID: " + spotifyTrackId);
		
		//Resources
		SpotifyResource spotifyResource = new SpotifyResource();
		YouTubeResource youtubeResource = new YouTubeResource();
		//MusixMatchResource musixmatchResource = new MusixMatchResource();
		
		// Result Get
		Track spotifyTrack = spotifyResource.getTrack(spotifyTrackId);
		
		
		if(spotifyTrack != null){
			request.setAttribute("spotifyTrack", spotifyTrack);
			
			//Searching for the song in YouTube
			log.log(Level.FINE, "Searching for the Song in YouTube with the spotifyTrackId: " + spotifyTrackId);
			
			//Result Get
			String queryYoutube = spotifyTrack.getArtists().get(0).getName() + " " + spotifyTrack.getName();
			VideosSearch youtubeVideos = youtubeResource.searchVideos(queryYoutube);
			
			//LyricsGet songLyrics = musixmatchResource.getLyrics(spotifyTrack.getName(), spotifyTrack.getArtists().get(0).getName());
			//response.getWriter().println("<p>" +songLyrics+"</p>");
			//response.getWriter().println("<p>" + spotifyTrack.getName() + spotifyTrack.getArtists().get(0).getName() + "</p>");
			
			if(youtubeVideos !=null){
				request.setAttribute("youtubeVideoId", youtubeVideos.getItems().isEmpty() ? "not_found" : youtubeVideos.getItems().get(0).getId().getVideoId());
				//request.setAttribute("lyrics", songLyrics.getMessage());
				
				rd = request.getRequestDispatcher("/trackView.jsp");
				
			}else{
				log.log(Level.SEVERE, "There was an error when retrieving:");
				
				objectErrorPool = new HashMap<String, Object>();
				
				if (youtubeVideos == null){
					log.log(Level.SEVERE, " - Videos from Youtube. Videos object: " + youtubeVideos);
					objectErrorPool.put("youtubeVideos", youtubeVideos);
				}
				
				request.setAttribute("objectsErrorKeySet", objectErrorPool.keySet());
				request.setAttribute("objectsErrorValues", objectErrorPool.values());
				
				rd = request.getRequestDispatcher("/error.jsp");
			}
			
		}else{
			
			log.log(Level.SEVERE, "There was an error when retrieving:");
			
			objectErrorPool = new HashMap<String, Object>();
			
			if (spotifyTrack == null){
				log.log(Level.SEVERE, " - Song from Spotify. Song object: " + spotifyTrack);
				objectErrorPool.put("spotifyTrack", spotifyTrack);
			}

			
			request.setAttribute("objectsErrorKeySet", objectErrorPool.keySet());
			request.setAttribute("objectsErrorValues", objectErrorPool.values());
			
			rd = request.getRequestDispatcher("/error.jsp");
		}
	
		rd.forward(request, response);
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
