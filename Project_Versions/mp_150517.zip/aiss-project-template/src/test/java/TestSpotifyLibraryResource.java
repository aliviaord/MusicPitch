import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.junit.BeforeClass;
import org.junit.Test;
import org.restlet.resource.ResourceException;

import aiss.model.resources.SpotifyLibraryResource;

public class TestSpotifyLibraryResource {

	private static final String access_token = "BQAMvZtKLpQLznMR52N2yNOY2M6utfFidE9nl5UqgyC9t4qD4d0doB41eCabKpmtK3PJuoyCp6MdEVKH49NNEas5DBzMA5i3gBU6FwlamuMiBYUi32JjE1d62-xkQjnL7b904QJ0yIWogoIp_Fs67w";
	private static SpotifyLibraryResource spotifyLibraryResource;
	
	@BeforeClass
	public static void setUp(){
		spotifyLibraryResource = new SpotifyLibraryResource(access_token);
	}
	
	@Test 
	public void testAddTrackNull(){
		String query = null;
		Boolean trackAdded = spotifyLibraryResource.addTrack(query);
		assertFalse("The song shouldn't have been added", trackAdded);
	}
	
	@Test 
	public void testAddNonExistingTrack(){
		String query = "blanche";
		Boolean trackAdded = spotifyLibraryResource.addTrack(query);
		assertFalse("The song shouldn't have been added", trackAdded);
	}
	
	@Test
	public void testAddPreExistingTrack(){
		String query = "2fQxE0jVrjNMT9oJAXtSJR";
		//Ariana Grande - My Everything Deluxe
		Boolean trackAdded = spotifyLibraryResource.addTrack(query);
		assertTrue("Spotify should tell us that the song was added even though it existed before", trackAdded);
	}
	
	@Test
	public void testAddTrack(){
		String query = "3yvZ1VUso9Xi7EvIyLaj4o";
		//Lorde - Royals
		Boolean trackAdded = spotifyLibraryResource.addTrack(query);
		assertTrue("The song should have been added", trackAdded);
	}
	
	@Test 
	public void testAddAlbumNull(){
		String query = null;
		Boolean trackAdded = spotifyLibraryResource.addAlbum(query);
		assertFalse("The album shouldn't have been added", trackAdded);
	}
	
	@Test 
	public void testAddNonExistingAlbum(){
		String query = "blanche";
		Boolean trackAdded = spotifyLibraryResource.addAlbum(query);
		assertFalse("The album shouldn't have been added", trackAdded);
	}
	
	@Test 
	public void testAddPreExistingAlbum(){
		String query = "5AMOKSM1ftb3opIbGT2d4q";
		//Ariana Grande - My Everything Deluxe
		Boolean trackAdded = spotifyLibraryResource.addAlbum(query);
		assertTrue("Spotify should tell us that the album was added even though it existed before", trackAdded);
	}
	
	@Test
	public void testAddAlbum(){
		String query = "3Ywlsvgu3H6L3q9NHydNR3";
		//Lorde - Pure Heroine
		Boolean trackAdded = spotifyLibraryResource.addAlbum(query);
		assertTrue("The album should have been added", trackAdded);
	}
	
}
