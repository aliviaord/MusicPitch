import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import java.io.UnsupportedEncodingException;

import org.junit.BeforeClass;
import org.junit.Test;

import aiss.model.resources.YouTubeResource;
import aiss.model.youtube.search.VideosSearch;

public class TestYoutubeResource {
	
	private static YouTubeResource youtubeResource;
	
	@BeforeClass
	public static void setUp() {
		youtubeResource = new YouTubeResource();
	}

	@Test(expected = NullPointerException.class)
	public void testSearchNull() throws NullPointerException, UnsupportedEncodingException {
		String query = null;
		VideosSearch youtubeVideos = youtubeResource.searchVideos(query);
	}
	
	@Test
	public void testSearchNotFound() throws UnsupportedEncodingException {
		String query = "Rodolfo Chikilcuatre Baila el Chiki Chiki (feat. Tata Golosa) - Original Mix";
		VideosSearch youtubeVideos = youtubeResource.searchVideos(query);
		assertNotNull("The youtubeVideos search returned null", youtubeVideos);
		assertNotNull("The youtubeVideos pageInfo returned null", youtubeVideos.getPageInfo());
		assertEquals("The youtubeVideos total results should be 0", new Integer(0),  youtubeVideos.getPageInfo().getTotalResults());
		assertTrue("The youtubeVideos items should be empty", youtubeVideos.getItems().isEmpty());
	}
	
	@Test
	public void testSearchFound() throws UnsupportedEncodingException {
		String query = "Dami Im Sound Of Silence";
		VideosSearch youtubeVideos = youtubeResource.searchVideos(query);
		assertNotNull("The youtubeVideos search returned null", youtubeVideos);
		assertNotNull("The youtubeVideos pageInfo returned null", youtubeVideos.getPageInfo());
		assertTrue("The youtubeVideos total results should be greater than 0 ", youtubeVideos.getPageInfo().getTotalResults() > 0);
		assertFalse("The youtubeVideos items should not be empty", youtubeVideos.getItems().isEmpty());
	}

}
