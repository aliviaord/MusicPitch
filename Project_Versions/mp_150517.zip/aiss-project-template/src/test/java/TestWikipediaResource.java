import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

import java.io.UnsupportedEncodingException;

import org.junit.BeforeClass;
import org.junit.Test;

import aiss.model.resources.WikipediaResource;
import aiss.model.wikipedia.search.BiographySearch;

public class TestWikipediaResource {

	private static WikipediaResource wikiResource;
	
	@BeforeClass
	public static void setUp(){
		wikiResource = new WikipediaResource();
	}
	
	@Test (expected = NullPointerException.class)
	public void testSearchNull() throws NullPointerException, UnsupportedEncodingException{
		String query = null;
		BiographySearch wikiBiographies = wikiResource.searchBiographies(query);
	}
	
	@Test
	public void testSearchEmpty() throws UnsupportedEncodingException{
		String query = "";
		BiographySearch wikiBiographies = wikiResource.searchBiographies(query);
		assertNotNull("The wikiBiographies returned null",wikiBiographies);
		assertTrue("The batchComplete property from wikiBiographies wasn't true",wikiBiographies.getBatchcomplete());
		assertNull("The wikiBiographies should be null",wikiBiographies.getQuery());
	}
	
	@Test
	public void testSearchNoPageFound() throws UnsupportedEncodingException{
		String query = "Antonio Pagudo";
		BiographySearch wikiBiographies = wikiResource.searchBiographies(query);
		assertNotNull("The wikiBiographies returned null",wikiBiographies);
		assertTrue("The batchComplete property from wikiBiographies wasn't true",wikiBiographies.getBatchcomplete());
		assertTrue("The missing property from wikiBiographies wasn't true",wikiBiographies.getQuery().getPages().get(0).getMissing());
	}
	
	@Test
	public void testSearchPageFound() throws UnsupportedEncodingException{
		String query = "Lady Gaga";
		BiographySearch wikiBiographies = wikiResource.searchBiographies(query);
		assertNotNull("The wikiBiographies returned null",wikiBiographies);
		assertTrue("The batchComplete property from wikiBiographies wasn't true",wikiBiographies.getBatchcomplete());
		assertTrue("The number of pages from wikiBiographies should be greater than 0", wikiBiographies.getQuery().getPages().size() > 0);
		assertNull("The missing property from wikiBiographies was present and should be null",wikiBiographies.getQuery().getPages().get(0).getMissing());
		assertNotNull("There wasn't any pageId in the wikiBiographies",wikiBiographies.getQuery().getPages().get(0).getPageid());
		assertNotNull("There wasn't any extract in the wikiBiographies",wikiBiographies.getQuery().getPages().get(0).getExtract());
	}
}
