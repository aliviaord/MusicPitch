
package aiss.model.musixmatch.lyricsGet;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "lyrics"
})
public class Body {

    @JsonProperty("lyrics")
    private Lyrics lyrics;

    @JsonProperty("lyrics")
    public Lyrics getLyrics() {
        return lyrics;
    }

    @JsonProperty("lyrics")
    public void setLyrics(Lyrics lyrics) {
        this.lyrics = lyrics;
    }

}
