package aiss.resourceTests;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.junit.BeforeClass;
import org.junit.Test;

import aiss.model.resources.SpotifyLibraryResource;

public class TestSpotifyLibraryResource {

	private static final String access_token = "BQDnzUsU4n5mw7uVtHBTJP7rrEsOaqFCUpWanh6XzTBDPn7VSEd8GJe1Gb7LSCGaWUZgnUdcIfd5m8pLU36W7P-E2RFVjhl1yRhIj7k1-vxG8H0FgR0fFhYm1n2sLnh9jtoNjJTAfustYqomeIre1w";
	private static SpotifyLibraryResource spotifyLibraryResource;
	
	@BeforeClass
	public static void setUp(){
		
		spotifyLibraryResource = new SpotifyLibraryResource(access_token);
	}
	
	@Test 
	public void testAddTrackNull(){
		String query = null;
		Boolean trackAdded = spotifyLibraryResource.addTrack(query);
		assertFalse("The song shouldn't have been added", trackAdded);
	}
	
	@Test 
	public void testAddNonExistingTrack(){
		String query = "blanche";
		Boolean trackAdded = spotifyLibraryResource.addTrack(query);
		assertFalse("The song shouldn't have been added", trackAdded);
	}
	
	@Test
	public void testAddPreExistingTrack(){
		String query = "2fQxE0jVrjNMT9oJAXtSJR";
		//Ariana Grande - My Everything Deluxe
		Boolean trackAdded = spotifyLibraryResource.addTrack(query);
		assertTrue("Spotify should tell us that the song was added even though it existed before", trackAdded);
	}
	
	@Test
	public void testAddTrack(){
		String query = "3yvZ1VUso9Xi7EvIyLaj4o";
		//Lorde - Royals
		Boolean trackAdded = spotifyLibraryResource.addTrack(query);
		assertTrue("The song should have been added", trackAdded);
	}
	
	@Test 
	public void testAddAlbumNull(){
		String query = null;
		Boolean trackAdded = spotifyLibraryResource.addAlbum(query);
		assertFalse("The album shouldn't have been added", trackAdded);
	}
	
	@Test 
	public void testAddNonExistingAlbum(){
		String query = "blanche";
		Boolean trackAdded = spotifyLibraryResource.addAlbum(query);
		assertFalse("The album shouldn't have been added", trackAdded);
	}
	
	@Test 
	public void testAddPreExistingAlbum(){
		String query = "5AMOKSM1ftb3opIbGT2d4q";
		//Ariana Grande - My Everything Deluxe
		Boolean trackAdded = spotifyLibraryResource.addAlbum(query);
		assertTrue("Spotify should tell us that the album was added even though it existed before", trackAdded);
	}
	
	@Test
	public void testAddAlbum(){
		String query = "3Ywlsvgu3H6L3q9NHydNR3";
		//Lorde - Pure Heroine
		Boolean trackAdded = spotifyLibraryResource.addAlbum(query);
		assertTrue("The album should have been added", trackAdded);
	}
	
}
