package aiss.resourceTests;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

import java.io.UnsupportedEncodingException;

import org.junit.BeforeClass;
import org.junit.Test;

import aiss.model.facebook.posts.Posts;
import aiss.model.facebook.search.pages.PagesSearch;
import aiss.model.resources.FacebookResource;

public class TestFacebookResource {

	private static FacebookResource facebookResource;

	@BeforeClass
	public static void setUp() {
		
		facebookResource = new FacebookResource(TestFacebookPostResource.access_token);
	}

	@Test(expected = NullPointerException.class)
	public void testSearchPagesNull() throws NullPointerException, UnsupportedEncodingException {
		String query = null;
		PagesSearch facebookPages = facebookResource.searchPages(query);
	}

	@Test
	public void testSearchPagesEmpty() throws UnsupportedEncodingException {
		String query = "";
		PagesSearch facebookPages = facebookResource.searchPages(query);
		assertNotNull("The facebookPages returned null.", facebookPages);
		assertTrue("Data of facebookPages should be empty",facebookPages.getData().isEmpty());
	}

	@Test
	public void testSearchPagesFound() throws UnsupportedEncodingException {
		String query = "Lady Gaga";
		PagesSearch facebookPages = facebookResource.searchPages(query);
		assertNotNull("The facebookPages didn't return null", facebookPages);
		assertTrue("There must be at least 1 page returned in facebookPages.", facebookPages.getData().size() > 0);
		assertEquals("The first page returned must be 'Lady Gaga'.", facebookPages.getData().get(0).getName(),
				"Lady Gaga");
	}

	@Test(expected = NullPointerException.class)
	public void testGetPostsNull() throws NullPointerException, UnsupportedEncodingException {
		String query = null;
		Posts facebookPosts = facebookResource.getPosts(query);
	}

	@Test
	public void testGetPostsEmpty() throws NullPointerException, UnsupportedEncodingException {
		String query = "";
		Posts facebookPosts = facebookResource.getPosts(query);
		assertNull("The facebookPosts returned null.", facebookPosts);
	}
}
