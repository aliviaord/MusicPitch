package aiss.resourceTests;

import static org.junit.Assert.assertTrue;

import java.io.UnsupportedEncodingException;
import java.util.Random;
import java.util.Scanner;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;

import aiss.model.resources.FacebookPostResource;

public class TestFacebookPostResource {

	public static final String access_token = "EAAGfqb6DxZCgBAA0i9cUvN4JzmbqQEhTTORs1JUfCSqLy1zZCXaCDq0XMI27gLiKQnTdEg8bRUjqWvp2jv39ZAPVLZCzi1LCpERtpXZCFkqvXM6uyCLvZBq2rLZBgaGhI9aERq32dk4UZC26qWLvlPjWQA0WYLuKVQoZD";
	private static FacebookPostResource facebookPostResource;

	@BeforeClass
	public static void setUp() {
		
		facebookPostResource = new FacebookPostResource(access_token);
	}

	@Test(expected = NullPointerException.class)
	public void testPostNull() throws NullPointerException, UnsupportedEncodingException {
		String query = null;
		facebookPostResource.publishPost(query);
	}

	@Test
	public void testPost() {
		String query = "JUnit: " + randomMessage();
		Boolean postPublished = facebookPostResource.publishPost(query);
		assertTrue("The post should have been posted.", postPublished);
	}
	
	private static String randomMessage(){
		
		Random r = new Random();
		String characters = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz123456789";
		StringBuilder sb = new StringBuilder();
		
		while(sb.length() < 10){
			sb.append(characters.charAt(r.nextInt(characters.length())));
		}
		
		return sb.toString();
	}
	
	

}
