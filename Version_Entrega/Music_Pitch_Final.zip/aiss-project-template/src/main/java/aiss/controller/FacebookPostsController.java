package aiss.controller;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import aiss.model.facebook.posts.Posts;
import aiss.model.resources.FacebookResource;

/**
 * Servlet implementation class FacebookPostsController
 */
public class FacebookPostsController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private static final Logger log = Logger.getLogger(FacebookPostsController.class.getName());

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public FacebookPostsController() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		RequestDispatcher rd = null;
		String fbAccessToken = (String) request.getSession().getAttribute("Facebook-token");
		String fbPageId = (String) request.getAttribute("fbPageId");

		if (fbAccessToken != null && fbAccessToken != "" && fbPageId != null) {

			log.log(Level.INFO, "There exists a token");
			log.log(Level.INFO, "Token: " + fbAccessToken);

			FacebookResource fbResource = new FacebookResource(fbAccessToken);

			Posts fbPosts = null;
			boolean emptyFlag = false;
			
			if (!fbPageId.equals("emptyFlag")) {
				 fbPosts = fbResource.getPosts(fbPageId);
			}else{
				emptyFlag = true;
			}

			if (emptyFlag || fbPosts != null) {
				String spotifyArtistId = request.getSession().getAttribute("spotifyArtistId") == null ? ""
						: (String) request.getSession().getAttribute("spotifyArtistId");
				request.getSession().removeAttribute("spotifyArtistId");
				request.setAttribute("fbPosts", emptyFlag ? "" : fbPosts.getData());
				rd = request.getRequestDispatcher("/ArtistController?spotifyArtistId=" + spotifyArtistId);

			} else {
				log.log(Level.SEVERE, "There was an error when retrieving the FB Posts. fbPosts Object: " + fbPosts);

				Map<String, Object> objectErrorPool = new HashMap<String, Object>();

				objectErrorPool.put("fbPosts", fbPosts);
				request.setAttribute("objectsErrorKeySet", objectErrorPool.keySet());
				request.setAttribute("objectsErrorValues", objectErrorPool.values());

				rd = request.getRequestDispatcher("/error.jsp");
			}

		} else {

			log.log(Level.SEVERE, "Trying to retrieve posts without identifying the fbPageId first!" + fbPageId);

			rd = request.getRequestDispatcher("/");
		}

		rd.forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
