package aiss.controller;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import aiss.model.resources.SongkickResource;
import aiss.model.resources.SpotifyResource;
import aiss.model.resources.WikipediaResource;
import aiss.model.songkick.search.ConcertsSearch;
import aiss.model.spotify.artist.Artist;
import aiss.model.spotify.search.albums.Albums;
import aiss.model.wikipedia.search.BiographySearch;

/**
 * Servlet implementation class ArtistController
 */
public class ArtistController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private static final Logger log = Logger.getLogger(SearchController.class.getName());

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public ArtistController() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub

		String spotifyArtistId = request.getParameter("spotifyArtistId");
		
		RequestDispatcher rd = null;
		Map<String, Object> objectErrorPool = null;

		// Retrieving an artist given its id
		log.log(Level.FINE, "Retrieving the Artist with the ID: " + spotifyArtistId);
		log.log(Level.FINE, "Retrieving the Albums of an artists with the spotifyArtistId: " + spotifyArtistId);

		// Resources
		SpotifyResource spotifyResource = new SpotifyResource();
		SongkickResource songkickResource = new SongkickResource();
		WikipediaResource wikiResource = new WikipediaResource();

		// Result Get
		Artist spotifyArtist = spotifyResource.getArtist(spotifyArtistId);
		Albums spotifyArtistAlbums = spotifyResource.getArtistAlbums(spotifyArtistId);

		if (spotifyArtist != null && spotifyArtistAlbums != null) {
			request.setAttribute("spotifyArtist", spotifyArtist);
			request.setAttribute("spotifyArtistAlbums", spotifyArtistAlbums.getItems());

			// Now that we have the Artist, we can search for it in SongKick and
			// Wikipedia
			log.log(Level.FINE, "Searching for the spotifyArtist in Wikipedia: " + spotifyArtist.getName());
			log.log(Level.FINE, "Searching for the spotifyArtist in Songkick: " + spotifyArtist.getName());

			// Results Search once we've got the artist
			ConcertsSearch songkickConcerts = songkickResource.searchConcerts(spotifyArtist.getName());
			BiographySearch wikiBiographies = wikiResource.searchBiographies(spotifyArtist.getName());

			if (songkickConcerts != null && wikiBiographies != null) {
				request.setAttribute("songkickConcerts", songkickConcerts.getResultsPage().getResults().getEvent());
				request.setAttribute("wikiBiography", wikiBiographies.getQuery().getPages().get(0).getMissing() == null
						? wikiBiographies.getQuery().getPages().get(0).getExtract() : "<p>This artist doesn't seem to be on Wikipedia</p>");

				if(request.getSession().getAttribute("Facebook-token") != null && request.getAttribute(("fbPosts")) == null){
					log.log(Level.INFO, "Start a new search for fb posts");
					rd = request.getRequestDispatcher("/FacebookSearchPagesController");
					
				}else{
					log.log(Level.INFO, "Show the artist view");
					rd = request.getRequestDispatcher("/artistView.jsp");
				}
				
				
			} else {
				log.log(Level.SEVERE, "There was an error when retrieving:");

				objectErrorPool = new HashMap<String, Object>();

				if (songkickConcerts == null) {
					log.log(Level.SEVERE, " - Concerts from Songkick. Concert object: " + songkickConcerts);
					objectErrorPool.put("songkickConcerts", songkickConcerts);
				}

				if (wikiBiographies == null) {
					log.log(Level.SEVERE, " - Biography from Wikipedia. Wikipedia object: " + wikiBiographies);
					objectErrorPool.put("wikipediaSearch", wikiBiographies);
				}

				request.setAttribute("objectsErrorKeySet", objectErrorPool.keySet());
				request.setAttribute("objectsErrorValues", objectErrorPool.values());

				rd = request.getRequestDispatcher("/error.jsp");

			}

		} else {

			log.log(Level.SEVERE, "There was an error when retrieving:");

			objectErrorPool = new HashMap<String, Object>();

			if (spotifyArtist == null) {
				log.log(Level.SEVERE, " - Artist from Spotify. Artist object: " + spotifyArtist);
				objectErrorPool.put("spotifyArtist", spotifyArtist);
			}

			if (spotifyArtistAlbums == null) {
				log.log(Level.SEVERE, " - Albums from Spotify. Albums object: " + spotifyArtistAlbums);
				objectErrorPool.put("spotifyArtistAlbums", spotifyArtistAlbums);
			}

			request.setAttribute("objectsErrorKeySet", objectErrorPool.keySet());
			request.setAttribute("objectsErrorValues", objectErrorPool.values());

			rd = request.getRequestDispatcher("/error.jsp");
		}

		rd.forward(request, response);

	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
