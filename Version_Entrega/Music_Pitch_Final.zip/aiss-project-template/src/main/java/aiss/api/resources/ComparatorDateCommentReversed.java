package aiss.api.resources;

import java.util.Comparator;

import aiss.api.model.Comment;

public class ComparatorDateCommentReversed implements Comparator<Comment>{

	@Override
	public int compare(Comment c1, Comment c2) {
		// TODO Auto-generated method stub
		return c2.getDate().compareTo(c1.getDate());
	}

}
