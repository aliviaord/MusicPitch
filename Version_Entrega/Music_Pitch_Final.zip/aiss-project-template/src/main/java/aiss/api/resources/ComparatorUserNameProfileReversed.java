package aiss.api.resources;

import java.util.Comparator;

import aiss.api.model.Profile;

public class ComparatorUserNameProfileReversed implements Comparator<Profile>{

	@Override
	public int compare(Profile p1, Profile p2) {
		return p2.getUserName().compareTo(p1.getUserName());
	}

}
