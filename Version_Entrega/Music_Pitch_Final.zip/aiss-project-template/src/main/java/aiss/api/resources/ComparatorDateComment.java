package aiss.api.resources;

import java.util.Comparator;

import aiss.api.model.Comment;

public class ComparatorDateComment implements Comparator<Comment>{

	@Override
	public int compare(Comment c1, Comment c2) {
		// TODO Auto-generated method stub
		return c1.getDate().compareTo(c2.getDate());
	}

}
