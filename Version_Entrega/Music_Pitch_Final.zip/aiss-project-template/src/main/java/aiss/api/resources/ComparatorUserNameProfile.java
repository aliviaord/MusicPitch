package aiss.api.resources;

import java.util.Comparator;

import aiss.api.model.Profile;

public class ComparatorUserNameProfile implements Comparator<Profile>{

	@Override
	public int compare(Profile p1, Profile p2) {
		return p1.getUserName().compareTo(p2.getUserName());
	}

}
