package aiss.controller;

import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import aiss.model.musixmatch.lyricsGet.LyricsGet;
import aiss.model.resources.MusixMatchResource;
import aiss.model.resources.SpotifyResource;
import aiss.model.resources.YouTubeResource;
import aiss.model.spotify.songGet.SongGet;
import aiss.model.youtube.video.VideoSearch;

/**
 * Servlet implementation class SongController
 */
public class SongController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	private static final Logger log = Logger.getLogger(SongController.class.getName());
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public SongController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String id = request.getParameter("id");
		
		SpotifyResource spotify = new SpotifyResource();
		YouTubeResource youtube = new YouTubeResource();
		//MusixMatchResource musixmatch = new MusixMatchResource();
		
		SongGet spotifySong = spotify.getSong(id);
		
		String queryEncoded = spotifySong.getArtists().get(0).getName() + " " + spotifySong.getName();
		VideoSearch youTubeVideo = youtube.getVideos(queryEncoded);
		
		//LyricsGet songLyrics = musixmatch.getLyrics(spotifySong.getName(), spotifySong.getArtists().get(0).getName());
		//response.getWriter().println("<p>" +songLyrics+"</p>");
		//response.getWriter().println("<p>" + spotifySong.getName() + spotifySong.getArtists().get(0).getName() + "</p>");
		RequestDispatcher rd = null;
		
		
		if(youTubeVideo != null) {
			rd = request.getRequestDispatcher("song.jsp");
			request.setAttribute("id", spotifySong.getId());
			request.setAttribute("name", spotifySong.getName());
			request.setAttribute("videos", youTubeVideo.getItems());
			//request.setAttribute("lyrics", songLyrics.getMessage());
		} else {
			log.log(Level.SEVERE, "YouTube object: " + youTubeVideo);
			rd = request.getRequestDispatcher("error.jsp");
			response.getWriter().println("<p>" + queryEncoded + "</p>");
		}
		
		rd.forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
