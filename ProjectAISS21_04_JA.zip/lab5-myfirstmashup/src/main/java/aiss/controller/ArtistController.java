package aiss.controller;

import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import aiss.model.resources.SongkickResource;
import aiss.model.resources.SpotifyResource;
import aiss.model.resources.WikipediaResource;
import aiss.model.songkick.search.ConcertSearch;
import aiss.model.spotify.artists.Item;
import aiss.model.wikipedia.biography.BiographySearch;

/**
 * Servlet implementation class ArtistController
 */
public class ArtistController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private static final Logger log = Logger.getLogger(SearchController.class.getName());
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ArtistController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String query = request.getParameter("artistId");
		SpotifyResource spotify = new SpotifyResource();
		Item artist = spotify.getArtist(query);
		aiss.model.spotify.albums2.Albums albums = spotify.getArtistAlbums(query);
		SongkickResource songkick = new SongkickResource();
		ConcertSearch concertSearch = songkick.getConcerts(artist.getName()); //Null pointer (?)
		WikipediaResource wikiResource = new WikipediaResource();
		BiographySearch bioSearch = wikiResource.getBiographies(artist.getName());
		
		
		
		RequestDispatcher rd = null;
		log.log(Level.FINE, "Searching for Spotify artist of " + query);
		
		response.getWriter().append("Served atw: ").append(request.getContextPath()).append(query);
		
		if (artist!=null && albums != null && concertSearch != null && bioSearch != null){
			request.setAttribute("artist", artist);
			request.setAttribute("albums", albums.getItems());
			request.setAttribute("concerts", concertSearch.getResultsPage().getResults().getEvent());
			request.setAttribute("bio", bioSearch.getQuery().getPages().get(0).getExtract());
			rd = request.getRequestDispatcher("/artist.jsp");
			System.out.println(albums.getItems().get(0).getImages().get(0).getUrl());
		} else {
			if(artist == null)
				log.log(Level.SEVERE, "Artist object: " + artist);
			
			if(albums == null)
				log.log(Level.SEVERE, "Albums object: " + albums);
			
			if(concertSearch == null)
				log.log(Level.SEVERE, "Concert object: " + concertSearch);
			
			if(bioSearch == null)
				log.log(Level.SEVERE, "Bio object: " + bioSearch);
			
			rd = request.getRequestDispatcher("/error.jsp");
		}
		
		rd.forward(request, response);
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
