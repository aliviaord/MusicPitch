package aiss.model.resources;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.logging.Logger;

import org.restlet.resource.ClientResource;
import org.restlet.resource.ResourceException;

import aiss.model.wikipedia.biography.BiographySearch;

public class WikipediaResource {

	private static final Logger log = Logger.getLogger(WikipediaResource.class.getName());
	
	public BiographySearch getBiographies(String query) throws UnsupportedEncodingException {
		
		BiographySearch res = null;
		ClientResource cr = null;

		try {
			String queryEncoded = URLEncoder.encode(query, "UTF-8");
			cr = new ClientResource("https://en.wikipedia.org/w/api.php?action=query&format=json&prop=extracts&exintro=1&formatversion=2&titles=" + queryEncoded);
			res = cr.get(BiographySearch.class);
		} catch (ResourceException e) {
			System.err.println("Error when retrieving biographies " + cr.getResponse().getStatus());
		}
		
		
		return res;
		
	}
	
}
