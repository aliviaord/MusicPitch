
package aiss.model.songkick.search;

import java.util.HashMap;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "status",
    "results",
    "perPage",
    "page",
    "totalEntries"
})
public class ResultsPage {

    @JsonProperty("status")
    private String status;
    @JsonProperty("results")
    private Results results;
    @JsonProperty("perPage")
    private Integer perPage;
    @JsonProperty("page")
    private Integer page;
    @JsonProperty("totalEntries")
    private Integer totalEntries;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("status")
    public String getStatus() {
        return status;
    }

    @JsonProperty("status")
    public void setStatus(String status) {
        this.status = status;
    }

    @JsonProperty("results")
    public Results getResults() {
        return results;
    }

    @JsonProperty("results")
    public void setResults(Results results) {
        this.results = results;
    }

    @JsonProperty("perPage")
    public Integer getPerPage() {
        return perPage;
    }

    @JsonProperty("perPage")
    public void setPerPage(Integer perPage) {
        this.perPage = perPage;
    }

    @JsonProperty("page")
    public Integer getPage() {
        return page;
    }

    @JsonProperty("page")
    public void setPage(Integer page) {
        this.page = page;
    }

    @JsonProperty("totalEntries")
    public Integer getTotalEntries() {
        return totalEntries;
    }

    @JsonProperty("totalEntries")
    public void setTotalEntries(Integer totalEntries) {
        this.totalEntries = totalEntries;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

}
