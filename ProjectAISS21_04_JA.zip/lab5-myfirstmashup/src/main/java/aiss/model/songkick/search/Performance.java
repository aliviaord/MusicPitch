
package aiss.model.songkick.search;

import java.util.HashMap;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "artist",
    "displayName",
    "billingIndex",
    "billing",
    "id"
})
public class Performance {

    @JsonProperty("artist")
    private Artist artist;
    @JsonProperty("displayName")
    private String displayName;
    @JsonProperty("billingIndex")
    private Integer billingIndex;
    @JsonProperty("billing")
    private String billing;
    @JsonProperty("id")
    private Integer id;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("artist")
    public Artist getArtist() {
        return artist;
    }

    @JsonProperty("artist")
    public void setArtist(Artist artist) {
        this.artist = artist;
    }

    @JsonProperty("displayName")
    public String getDisplayName() {
        return displayName;
    }

    @JsonProperty("displayName")
    public void setDisplayName(String displayName) {
        this.displayName = displayName;
    }

    @JsonProperty("billingIndex")
    public Integer getBillingIndex() {
        return billingIndex;
    }

    @JsonProperty("billingIndex")
    public void setBillingIndex(Integer billingIndex) {
        this.billingIndex = billingIndex;
    }

    @JsonProperty("billing")
    public String getBilling() {
        return billing;
    }

    @JsonProperty("billing")
    public void setBilling(String billing) {
        this.billing = billing;
    }

    @JsonProperty("id")
    public Integer getId() {
        return id;
    }

    @JsonProperty("id")
    public void setId(Integer id) {
        this.id = id;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

}
