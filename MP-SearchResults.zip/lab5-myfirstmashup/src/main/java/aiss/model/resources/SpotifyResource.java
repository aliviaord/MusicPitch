package aiss.model.resources;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.restlet.resource.ClientResource;

import aiss.model.spotify.albums.AlbumSearch;
import aiss.model.spotify.artists.ArtistSearch;
import aiss.model.spotify.tracks.Album;
import aiss.model.spotify.tracks.TrackSearch;

public class SpotifyResource {


	private static final Logger log = Logger.getLogger(SpotifyResource.class.getName());
	
	public AlbumSearch getAlbums(String query) throws UnsupportedEncodingException {
		
		String album = URLEncoder.encode(query, "UTF-8");
	    ClientResource cr = new ClientResource("https://api.spotify.com/v1/search?q="+album+"&type=album");
	    AlbumSearch as = cr.get(AlbumSearch.class);
	    return as;
		
	}
	
	public TrackSearch getTracks(String query) throws UnsupportedEncodingException{
		String track = URLEncoder.encode(query, "UTF-8");
		ClientResource cr = new ClientResource("https://api.spotify.com/v1/search?q="+track+"&type=track");
		TrackSearch t = cr.get(TrackSearch.class);
		return t;
	}
	
	public ArtistSearch getArtists(String query) throws UnsupportedEncodingException{
		String artist = URLEncoder.encode(query, "UTF-8");
		ClientResource cr = new ClientResource("https://api.spotify.com/v1/search?q="+artist+"&type=artist");
		ArtistSearch as = cr.get(ArtistSearch.class);
		return as;
	}
}
