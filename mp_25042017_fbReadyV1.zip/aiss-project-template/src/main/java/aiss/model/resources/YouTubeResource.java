package aiss.model.resources;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.restlet.resource.ClientResource;
import org.restlet.resource.ResourceException;

import aiss.model.youtube.search.VideosSearch;

public class YouTubeResource {

	private static final Logger log = Logger.getLogger(YouTubeResource.class.getName());
	private static final String key = "AIzaSyC0l2CpsH0Qq-wTc12Yvp90MeVAlf_Chjs";

	public VideosSearch searchVideos(String query) throws UnsupportedEncodingException {

		VideosSearch res = null;
		ClientResource cr = null;

		try {
			String queryEncoded = URLEncoder.encode(query, "UTF-8");
			cr = new ClientResource("https://www.googleapis.com/youtube/v3/search?part=id&q=" + queryEncoded
					+ "&type=video&key=" + key);
			res = cr.get(VideosSearch.class);
		} catch (ResourceException e) {
			log.log(Level.SEVERE, "Error when retrieving Youtube Videos" + cr.getResponse().getStatus());
		}

		return res;

	}
}
