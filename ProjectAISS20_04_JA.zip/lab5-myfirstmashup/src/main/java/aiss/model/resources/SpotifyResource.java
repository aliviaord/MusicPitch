package aiss.model.resources;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.logging.Logger;

import org.restlet.resource.ClientResource;
import org.restlet.resource.ResourceException;

import aiss.model.spotify.album.AlbumGet;
import aiss.model.spotify.albums.AlbumSearch;
import aiss.model.spotify.albums.Albums;
import aiss.model.spotify.artists.ArtistSearch;
import aiss.model.spotify.artists.Item;

public class SpotifyResource {

	private static final Logger log = Logger.getLogger(SpotifyResource.class.getName());

	public AlbumSearch getAlbums(String query) throws UnsupportedEncodingException {

		AlbumSearch res = null;
		ClientResource cr = null;

		try {
			String queryEncoded = URLEncoder.encode(query, "utf-8");
			cr = new ClientResource("https://api.spotify.com/v1/search?q=" + queryEncoded + "&type=album");
			res = cr.get(AlbumSearch.class);
		} catch (ResourceException e) {
			System.err.println("Error when retrieving albums " + cr.getResponse().getStatus());
		}

		return res;
	}

	public ArtistSearch getArtists(String query) throws UnsupportedEncodingException {

		ArtistSearch res = null;
		ClientResource cr = null;
		String queryEncoded = null;

		try {
			queryEncoded = URLEncoder.encode(query, "utf-8");
			cr = new ClientResource("https://api.spotify.com/v1/search?q=" + queryEncoded + "&type=artist");
			res = cr.get(ArtistSearch.class);
		} catch (ResourceException e) {
			e.printStackTrace();
			System.err.println(
					"Error when retrieving artists " + cr.getResponse().getStatus() + " MENSAJE: " + e.getMessage());
			System.out.println("\t --- Proceding to DUMP -- ");
			System.out.println("\t URI: " + "https://api.spotify.com/v1/search?q=" + queryEncoded + "&type=artist");
			try {
				System.out.println("\t CR: " + cr.get().getText());
			} catch (ResourceException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}

		return res;
	}

	public Item getArtist(String query) throws UnsupportedEncodingException {

		Item res = null;
		ClientResource cr = null;
		String queryEncoded = null;

		try {
			queryEncoded = URLEncoder.encode(query, "utf-8");
			cr = new ClientResource("https://api.spotify.com/v1/artists/" + queryEncoded);
			res = cr.get(Item.class);
		} catch (ResourceException e) {
			System.err.println("Error when retrieving artist " + cr.getResponse().getStatus());
		}

		return res;

	}

	public Albums getArtistAlbums(String query) throws UnsupportedEncodingException {

		Albums res = null;
		ClientResource cr = null;
		String queryEncoded = null;

		try {
			queryEncoded = URLEncoder.encode(query, "utf-8");
			cr = new ClientResource("https://api.spotify.com/v1/artists/" + queryEncoded
					+ "/albums?album_type=single,album,appears_on&market=ES");
			res = cr.get(Albums.class);
		} catch (ResourceException e) {
			System.err.println("Error when retrieving albums " + cr.getResponse().getStatus());
		}

		return res;

	}

	public AlbumGet getAlbum(String query) throws UnsupportedEncodingException {

		AlbumGet res = null;
		ClientResource cr = null;
		String queryEncoded = null;

		try {
			queryEncoded = URLEncoder.encode(query, "utf-8");
			cr = new ClientResource("https://api.spotify.com/v1/albums/" + queryEncoded
					+ "?market=ES");
			res = cr.get(AlbumGet.class);
		} catch (ResourceException e) {
			System.err.println("Error when retrieving albums " + cr.getResponse().getStatus());
		}

		return res;

	}

}
