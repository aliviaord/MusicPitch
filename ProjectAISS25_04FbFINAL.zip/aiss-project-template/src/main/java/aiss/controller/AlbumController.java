package aiss.controller;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import aiss.model.resources.SpotifyResource;
import aiss.model.spotify.album.Album;

/**
 * Servlet implementation class AlbumController
 */
public class AlbumController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private static final Logger log = Logger.getLogger(SearchController.class.getName());
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AlbumController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		
		String spotifyAlbumId = request.getParameter("spotifyAlbumId");
		RequestDispatcher rd = null;
		
		//Retrieving an album given its id
		log.log(Level.FINE, "Retrieving the Album with the ID: " + spotifyAlbumId);
		
		//Resources
		SpotifyResource spotifyResource = new SpotifyResource();
		
		
		//Results of Get
		Album spotifyAlbum = spotifyResource.getAlbum(spotifyAlbumId);
		
		
		if (spotifyAlbum!=null){
			request.setAttribute("spotifyAlbum", spotifyAlbum);
			rd = request.getRequestDispatcher("/albumView.jsp");
			
		} else {
			log.log(Level.SEVERE, "There was an error when retrieving the Album. Album Object: " + spotifyAlbum);
			
			Map<String,Object> objectErrorPool = new HashMap<String,Object>();
			
			objectErrorPool.put("spotifyAlbum", spotifyAlbum);
			request.setAttribute("objectsErrorKeySet", objectErrorPool.keySet());
			request.setAttribute("objectsErrorValues", objectErrorPool.values());
			
			rd = request.getRequestDispatcher("/error.jsp");
		}
		
		rd.forward(request, response);
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
