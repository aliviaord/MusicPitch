
package aiss.model.facebook.posts;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "created_time",
    "message",
    "id",
    "story"
})
public class Datum {

    @JsonProperty("created_time")
    private String createdTime;
    @JsonProperty("message")
    private String message;
    @JsonProperty("id")
    private String id;
    @JsonProperty("story")
    private String story;

    @JsonProperty("created_time")
    public String getCreatedTime() {
        return createdTime;
    }

    @JsonProperty("created_time")
    public void setCreatedTime(String createdTime) {
        this.createdTime = createdTime;
    }

    @JsonProperty("message")
    public String getMessage() {
        return message;
    }

    @JsonProperty("message")
    public void setMessage(String message) {
        this.message = message;
    }

    @JsonProperty("id")
    public String getId() {
        return id;
    }

    @JsonProperty("id")
    public void setId(String id) {
        this.id = id;
    }

    @JsonProperty("story")
    public String getStory() {
        return story;
    }

    @JsonProperty("story")
    public void setStory(String story) {
        this.story = story;
    }

}
