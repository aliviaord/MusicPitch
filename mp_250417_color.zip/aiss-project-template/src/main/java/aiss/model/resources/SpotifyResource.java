package aiss.model.resources;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.restlet.resource.ClientResource;
import org.restlet.resource.ResourceException;

import aiss.model.spotify.album.Album;
import aiss.model.spotify.artist.Artist;
import aiss.model.spotify.search.albums.Albums;
import aiss.model.spotify.search.albums.AlbumsSearch;
import aiss.model.spotify.search.artists.ArtistsSearch;
import aiss.model.spotify.search.tracks.TracksSearch;
import aiss.model.spotify.track.Track;

public class SpotifyResource {

	private static final Logger log = Logger.getLogger(SpotifyResource.class.getName());

	// Searches

	public AlbumsSearch searchAlbums(String query) throws UnsupportedEncodingException {

		AlbumsSearch res = null;
		ClientResource cr = null;

		try {
			String queryEncoded = URLEncoder.encode(query, "UTF-8");
			cr = new ClientResource("https://api.spotify.com/v1/search?q=" + queryEncoded + "&type=album");
			res = cr.get(AlbumsSearch.class);
		} catch (ResourceException e) {
			log.log(Level.SEVERE,"Error when retrieving albums " + cr.getResponse().getStatus());
		}

		return res;

	}

	public TracksSearch searchTracks(String query) throws UnsupportedEncodingException {

		TracksSearch res = null;
		ClientResource cr = null;

		try {

			String queryEncoded = URLEncoder.encode(query, "UTF-8");
			cr = new ClientResource("https://api.spotify.com/v1/search?q=" + queryEncoded + "&type=track");
			res = cr.get(TracksSearch.class);

		} catch (ResourceException e) {
			log.log(Level.SEVERE,"Error when retrieving tracks " + cr.getResponse().getStatus());
		}

		return res;
	}

	public ArtistsSearch searchArtists(String query) throws UnsupportedEncodingException {

		ArtistsSearch res = null;
		ClientResource cr = null;

		try {
			String queryEncoded = URLEncoder.encode(query, "UTF-8");
			cr = new ClientResource("https://api.spotify.com/v1/search?q=" + queryEncoded + "&type=artist");
			res = cr.get(ArtistsSearch.class);
		} catch (ResourceException e) {
			log.log(Level.SEVERE,"Error when retrieving artists " + cr.getResponse().getStatus());
		}

		return res;
	}

	// Gets

	public Track getTrack(String query) throws UnsupportedEncodingException {

		Track res = null;
		ClientResource cr = null;

		try {
			String queryEncoded = URLEncoder.encode(query, "UTF-8");
			cr = new ClientResource("https://api.spotify.com/v1/tracks/" + queryEncoded);
			res = cr.get(Track.class);
		} catch (ResourceException e) {
			log.log(Level.SEVERE,"Error when getting songs " + cr.getResponse().getStatus());
		}

		return res;
	}

	public Artist getArtist(String query) throws UnsupportedEncodingException {
		
		Artist res = null;
		ClientResource cr = null;

		try {
			String queryEncoded = URLEncoder.encode(query, "UTF-8");
			cr = new ClientResource("https://api.spotify.com/v1/artists/" + queryEncoded);
			res = cr.get(Artist.class);

		} catch (ResourceException e) {
			log.log(Level.SEVERE,"Error when retrieving artist " + cr.getResponse().getStatus());
		}

		return res;
	}

	public Albums getArtistAlbums(String query) throws UnsupportedEncodingException {

		Albums res = null;
		ClientResource cr = null;

		try {
			String queryEncoded = URLEncoder.encode(query, "utf-8");
			cr = new ClientResource("https://api.spotify.com/v1/artists/" + queryEncoded
					+ "/albums?album_type=single,album,appears_on&market=ES");
			res = cr.get(Albums.class);

		} catch (ResourceException e) {
			log.log(Level.SEVERE,"Error when getting albums of an artist " + cr.getResponse().getStatus());
		}

		return res;
	}

	public Album getAlbum(String query) throws UnsupportedEncodingException {

		Album res = null;
		ClientResource cr = null;

		try {
			String queryEncoded = URLEncoder.encode(query, "utf-8");
			//TODO: Market ES?
			cr = new ClientResource("https://api.spotify.com/v1/albums/" + queryEncoded + "?market=ES");
			res = cr.get(Album.class);

		} catch (ResourceException e) {
			log.log(Level.SEVERE,"Error when getting albums " + cr.getResponse().getStatus());
		}

		return res;

	}

}
