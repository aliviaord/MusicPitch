package aiss.controller;

import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import aiss.model.facebook.posts.Posts;
import aiss.model.resources.FacebookResource;

/**
 * Servlet implementation class FacebookPostsController
 */
public class FacebookPostsController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private static final Logger log = Logger.getLogger(FacebookPostsController.class.getName());
	private String pageId;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public FacebookPostsController() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		RequestDispatcher rd = null;
		String fbAccessToken = (String) request.getSession().getAttribute("Facebook-token");

		if (fbAccessToken != null && fbAccessToken != "") {

			log.log(Level.INFO, "There exists a token");
			log.log(Level.INFO, "Token: " + fbAccessToken);

			FacebookResource fbResource = new FacebookResource(fbAccessToken);

			if (request.getParameter("fbPageIdPrueba") != null) {
				
				log.log(Level.INFO, "getParameter: ");
				pageId = request.getParameter("fbPageIdPrueba");
				
			} else if (request.getAttribute("fbPageIdPrueba") != null) {
				
				log.log(Level.INFO, "getAttribute NO SESSION");
				pageId = request.getAttribute("fbPageIdPrueba").toString();
				
			} else if (request.getSession().getAttribute("fbPageId") != null) {
				
				log.log(Level.INFO, "Session: ");
				pageId = request.getSession().getAttribute("fbPageId").toString();
				
			}

			Posts fbPosts = fbResource.getPosts(pageId);

			request.setAttribute("fbPosts", fbPosts.getData());
			request.setAttribute("spotifyArtistId", request.getSession().getAttribute("spotifyArtistId"));
			rd = request.getRequestDispatcher("/ArtistController");
			
		} else {
			log.log(Level.INFO, "A tomar por culo.");
			log.log(Level.INFO, "Tu token de mierda: " + fbAccessToken);
			pageId = request.getSession().getAttribute("andiwonderifyouknow").toString();
			rd = request.getRequestDispatcher("/AuthController/Facebook");
		}

		rd.forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
