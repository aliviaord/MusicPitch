package aiss.controller;

import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import aiss.model.facebook.search.pages.PagesSearch;
import aiss.model.resources.FacebookResource;

/**
 * Servlet implementation class FacebookSearchUserController
 */
public class FacebookSearchPagesController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private static final Logger log = Logger.getLogger(FacebookSearchPagesController.class.getName());
	private String fbQuery;

	public FacebookSearchPagesController() {
		super();
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
	

		RequestDispatcher rd = null;
		String fbAccessToken = (String) request.getSession().getAttribute("Facebook-token");

		if (fbAccessToken != null && fbAccessToken != "") {
			
			log.log(Level.INFO, "There exists a token");
			log.log(Level.INFO, "Token: " + fbAccessToken);

			FacebookResource fbResource = new FacebookResource(fbAccessToken);
			
			if (request.getParameter("fbQuery") != null) {
				fbQuery = request.getParameter("fbQuery");
			}
			
			log.log(Level.INFO, "Facebook Query" + fbQuery);
			PagesSearch fbPages = fbResource.searchPages(fbQuery);

			if (fbPages != null) {
				
				request.setAttribute("fbPageIdPrueba", fbPages.getData().get(0).getId());
				request.getSession().setAttribute("fbPageId", fbPages.getData().get(0).getId());
				rd = request.getRequestDispatcher("/ArtistController");
				
			} else {
				
				log.log(Level.INFO, "fbPages Object is NULL!");
				rd = request.getRequestDispatcher("/error.jsp");
			}

		} else {
			
			log.log(Level.INFO, "Trying to access without a token");
		
			//We save the spotifyArtistId to retrieve it when auth is complete
			request.getSession().setAttribute("spotifyArtistId", request.getParameter("spotifyArtistId"));
			
			fbQuery = request.getParameter("fbQuery");
			log.log(Level.INFO, "fbQuery: " + fbQuery);
			
			rd = request.getRequestDispatcher("/AuthController/Facebook");
		}
		
		rd.forward(request, response);

	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
