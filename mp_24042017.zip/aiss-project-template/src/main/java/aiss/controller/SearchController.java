package aiss.controller;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import aiss.model.resources.SpotifyResource;
import aiss.model.spotify.search.albums.AlbumsSearch;
import aiss.model.spotify.search.artists.ArtistsSearch;
import aiss.model.spotify.search.tracks.TracksSearch;


/**
 * Servlet implementation class SearchController
 */
public class SearchController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	private static final Logger log = Logger.getLogger(SearchController.class.getName());
	 
    /**
     * @see HttpServlet#HttpServlet()
     */
    public SearchController() {
        super();
    }
    
	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {	
		
		String searchQuery = request.getParameter("searchQuery");
		RequestDispatcher rd = null;
		
		// Search for albums,songs and artists in Spotify
		log.log(Level.FINE, "Searching for Spotify albums,songs and artists of " + searchQuery);
		
		//Resources
		SpotifyResource spotifyResource = new SpotifyResource();
		
		//Results of Search
		AlbumsSearch spotifyAlbums = spotifyResource.searchAlbums(searchQuery);
		TracksSearch spotifyTracks = spotifyResource.searchTracks(searchQuery);
		ArtistsSearch spotifyArtists = spotifyResource.searchArtists(searchQuery);
		
		if (spotifyAlbums!=null && spotifyArtists != null && spotifyTracks != null){
			
			request.setAttribute("spotifyAlbums", spotifyAlbums.getAlbums().getItems());
			request.setAttribute("spotifyArtists", spotifyArtists.getArtists().getItems());
			request.setAttribute("spotifyTracks", spotifyTracks.getTracks().getItems());
			rd = request.getRequestDispatcher("/searchResults.jsp");
			
		} else {
			
			log.log(Level.SEVERE, "There was an error when retrieving:");
			
			Map<String,Object> objectErrorPool = new HashMap<String,Object>();
			
			if(spotifyAlbums == null){
				log.log(Level.SEVERE, " - Spotify Albums. Albums Object: " + spotifyAlbums);
				objectErrorPool.put("spotifyAlbums", spotifyAlbums);
			}
				
			
			if(spotifyTracks == null){
				log.log(Level.SEVERE, " - Spotify Tracks. Tracks Object: " + spotifyTracks);
				objectErrorPool.put("spotifyTracks", spotifyTracks);
			}
				
			
			if(spotifyArtists == null){
				log.log(Level.SEVERE, " - Spotify Artists. Artists Object: " + spotifyArtists);
				objectErrorPool.put("spotifyArtists", spotifyArtists);
			}
				
			request.setAttribute("objectsErrorKeySet", objectErrorPool.keySet());
			request.setAttribute("objectsErrorValues", objectErrorPool.values());
			
			rd = request.getRequestDispatcher("/error.jsp");
		}
		
		rd.forward(request, response);
	}
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}
	
}
