package aiss.model.resources;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.restlet.data.MediaType;
import org.restlet.engine.Engine;
import org.restlet.ext.jackson.JacksonConverter;
import org.restlet.resource.ClientResource;
import org.restlet.resource.ResourceException;

import com.google.appengine.repackaged.com.google.gson.Gson;

import aiss.model.musixmatch.lyricsGet.LyricsGet;

public class MusixMatchResource {

	private static final Logger log = Logger.getLogger(MusixMatchResource.class.getName());
	private static final String key = "b56494c60baa3866eb8ad55eb4fe80c7";
	
	public LyricsGet getLyrics(String query1, String query2) throws UnsupportedEncodingException {
		
		String songName = null;
		String artistName = null;
		
		ClientResource cr = null;
		
	    LyricsGet ls = null;
	    
	    try {
	    	   songName = URLEncoder.encode(query1, "UTF-8");
	    	   artistName = URLEncoder.encode(query2, "UTF-8");
	    	   cr = new ClientResource("http://api.musixmatch.com/ws/1.1/matcher.lyrics.get?apikey=" + key + "&q_track=" + songName + "&q_artist=" + artistName);
	    	   
	    	   //Gson gson = new Gson();
	    	   //ls = gson.fromJson(cr.get().getText(), LyricsGet.class);
	    	   
	    	   //log.log(Level.INFO, "HOLITAAAAAAA1" + ls.getMessage().getBody().getLyrics().toString());
	    	   log.log(Level.INFO, "HOLITAAAAAAA1" + songName);
	    	   log.log(Level.INFO,"http://api.musixmatch.com/ws/1.1/matcher.lyrics.get?apikey=" + key + "&q_track=" + songName + "&q_artist=" + artistName);
	    	   
	    	  } catch (ResourceException e) {
	    		  System.err.println("Error when retrieving albums " + cr.getResponse().getStatus());
	    		  log.log(Level.INFO, "HOLITAAAAAAA2" + cr.get().toString());
	    		  log.log(Level.INFO, "HOLITAAAAAAA2" + songName);
	    		  log.log(Level.INFO, "HOLITAAAAAAA2" + artistName);
	    		  
	    	  } catch (Exception ex) {
	    		  log.log(Level.INFO, "HOLITAAAAAAA3" + songName);
		    	  log.log(Level.INFO, "HOLITAAAAAAA3" + artistName);
	    	  }
	    
	    return ls;
		
	}
}
