package aiss.model.resources;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.restlet.resource.ClientResource;

import aiss.model.spotify.albums.AlbumSearch;
import aiss.model.spotify.artists.ArtistSearch;
import aiss.model.spotify.songGet.SongGet;
import aiss.model.spotify.tracks.TrackSearch;

public class SpotifyResource {


	private static final Logger log = Logger.getLogger(SpotifyResource.class.getName());
	
	public AlbumSearch getAlbums(String query) throws UnsupportedEncodingException {
		
		String album = URLEncoder.encode(query, "UTF-8");
	    ClientResource cr = new ClientResource("https://api.spotify.com/v1/search?q="+album+"&type=album");
	    //log.log(Level.INFO, "HOLITAAAASPOTIIIIIIAAA1" + cr.get().toString());
	    AlbumSearch as = cr.get(AlbumSearch.class);
	    return as;
		
	}
	
	public TrackSearch getTracks(String query) throws UnsupportedEncodingException{
		String track = URLEncoder.encode(query, "UTF-8");
		ClientResource cr = new ClientResource("https://api.spotify.com/v1/search?q="+track+"&type=track");
		TrackSearch t = cr.get(TrackSearch.class);
		return t;
	}
	
	public ArtistSearch getArtists(String query) throws UnsupportedEncodingException{
		String artist = URLEncoder.encode(query, "UTF-8");
		ClientResource cr = new ClientResource("https://api.spotify.com/v1/search?q="+artist+"&type=artist");
		ArtistSearch as = cr.get(ArtistSearch.class);
		return as;
	}
	
	public SongGet getSong(String query) throws UnsupportedEncodingException {
		String id = URLEncoder.encode(query, "UTF-8");
		ClientResource cr = new ClientResource("https://api.spotify.com/v1/tracks/" + id);
		SongGet sg = cr.get(SongGet.class);
		return sg;
	}
}
