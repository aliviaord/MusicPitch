package aiss.model.resources;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.restlet.resource.ClientResource;
import org.restlet.resource.ResourceException;

import aiss.model.musixmatch.lyrics.Lyrics;

public class MusixMatchResource {

	private static final Logger log = Logger.getLogger(MusixMatchResource.class.getName());
	private static final String key = "b56494c60baa3866eb8ad55eb4fe80c7";

	public Lyrics getLyrics(String queryTrack, String queryArtist) throws UnsupportedEncodingException {

		Lyrics res = null;
		ClientResource cr = null;

		try {
			String queryTrackEncoded = URLEncoder.encode(queryTrack, "UTF-8");
			String queryArtistEncoded = URLEncoder.encode(queryArtist, "UTF-8");

			cr = new ClientResource("http://api.musixmatch.com/ws/1.1/matcher.lyrics.get?apikey=" + key + "&q_track="
					+ queryTrackEncoded + "&q_artist=" + queryArtistEncoded);
			
			res = new Lyrics(cr.get().getText());

		} catch (ResourceException e) {
			log.log(Level.SEVERE, "Error when retrieving the lyrics " + cr.getResponse().getStatus());

		} catch (IOException e){
			log.log(Level.SEVERE, " There was an IOException " + cr.getResponse().getStatus());
			
		}

		return res;

	}
}
