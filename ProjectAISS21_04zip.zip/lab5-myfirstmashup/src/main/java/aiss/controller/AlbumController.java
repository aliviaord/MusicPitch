package aiss.controller;

import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import aiss.model.resources.SpotifyResource;
import aiss.model.spotify.album.AlbumGet;

/**
 * Servlet implementation class AlbumController
 */
public class AlbumController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private static final Logger log = Logger.getLogger(SearchController.class.getName());
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AlbumController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String albumId = request.getParameter("albumId");
		SpotifyResource spotify = new SpotifyResource();
		AlbumGet album = spotify.getAlbum(albumId);
		RequestDispatcher rd = null;
		log.log(Level.FINE, "Searching for Spotify album of " + albumId);
		
		response.getWriter().append("Served at: ").append(request.getContextPath()).append(albumId);
		
		if (album!=null){
			rd = request.getRequestDispatcher("/album.jsp");
			request.setAttribute("album", album);
		} else {
			log.log(Level.SEVERE, "Album object: " + album);
			rd = request.getRequestDispatcher("/error.jsp");
		}
		
		rd.forward(request, response);
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
