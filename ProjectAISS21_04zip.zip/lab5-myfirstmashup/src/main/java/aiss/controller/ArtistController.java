package aiss.controller;

import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.stream.Collectors;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import aiss.model.resources.SpotifyResource;
import aiss.model.spotify.albums.Albums;
import aiss.model.spotify.artists.Item;

/**
 * Servlet implementation class ArtistController
 */
public class ArtistController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private static final Logger log = Logger.getLogger(SearchController.class.getName());
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ArtistController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String query = request.getParameter("artistId");
		SpotifyResource spotify = new SpotifyResource();
		Item artist = spotify.getArtist(query);
		aiss.model.spotify.albums2.Albums albums = spotify.getArtistAlbums(query);
		RequestDispatcher rd = null;
		log.log(Level.FINE, "Searching for Spotify artist of " + query);
		
		response.getWriter().append("Served atw: ").append(request.getContextPath()).append(query);
		
		if (artist!=null){
			rd = request.getRequestDispatcher("/artist.jsp");
			request.setAttribute("artist", artist);
		} else {
			log.log(Level.SEVERE, "Artist object: " + artist);
			rd = request.getRequestDispatcher("/error.jsp");
		}
		
		if (albums!=null){
			rd = request.getRequestDispatcher("/artist.jsp");
			request.setAttribute("albums", albums.getItems());
			System.out.println(albums.getItems().get(0).getImages().get(0).getUrl());
		} else {
			log.log(Level.SEVERE, "Albums object: " + albums);
			rd = request.getRequestDispatcher("/error.jsp");
		}
		rd.forward(request, response);
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
