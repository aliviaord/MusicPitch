package aiss.model.resources;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.restlet.resource.ClientResource;
import org.restlet.resource.ResourceException;

import aiss.model.spotify.album.AlbumGet;
import aiss.model.spotify.albums.AlbumSearch;
import aiss.model.spotify.albums2.Albums;
import aiss.model.spotify.artists.ArtistSearch;
import aiss.model.spotify.artists.Item;
import aiss.model.spotify.songGet.SongGet;
import aiss.model.spotify.tracks.TrackSearch;

public class SpotifyResource {


	private static final Logger log = Logger.getLogger(SpotifyResource.class.getName());
	
	public AlbumSearch getAlbums(String query) throws UnsupportedEncodingException {
		
		AlbumSearch res = null;
		ClientResource cr = null;
		
		try {
			String album = URLEncoder.encode(query, "UTF-8");
			cr = new ClientResource("https://api.spotify.com/v1/search?q="+ album + "&type=album");
			res = cr.get(AlbumSearch.class);
		} catch (ResourceException e) {
			System.err.println("Error when retrieving albums " + cr.getResponse().getStatus());
		}
		
	    return res;
		
	}
	
	public TrackSearch getTracks(String query) throws UnsupportedEncodingException{
		String track = URLEncoder.encode(query, "UTF-8");
		ClientResource cr = new ClientResource("https://api.spotify.com/v1/search?q="+track+"&type=track");
		TrackSearch t = cr.get(TrackSearch.class);
		return t;
	}
	
	public ArtistSearch getArtists(String query) throws UnsupportedEncodingException{
		
		ArtistSearch res = null;
		ClientResource cr = null;
		String artist = null;
		
		try {
			artist = URLEncoder.encode(query, "UTF-8");
			cr = new ClientResource("https://api.spotify.com/v1/search?q=" + artist + "&type=artist");
			res = cr.get(ArtistSearch.class);
		} catch (ResourceException e) {
			System.err.println("Error when retrieving artists " + cr.getResponse().getStatus());
		}
	
		return res;
	}
	
	public SongGet getSong(String query) throws UnsupportedEncodingException {
		String id = URLEncoder.encode(query, "UTF-8");
		ClientResource cr = new ClientResource("https://api.spotify.com/v1/tracks/" + id);
		SongGet sg = cr.get(SongGet.class);
		return sg;
	}
	
	public Item getArtist(String query) throws UnsupportedEncodingException {
		Item res = null;
		ClientResource cr = null;
		String queryEncoded = null;

		try {
			queryEncoded = URLEncoder.encode(query, "utf-8");
			cr = new ClientResource("https://api.spotify.com/v1/artists/" + queryEncoded);
			res = cr.get(Item.class);
			
		} catch (ResourceException e) {
			System.err.println("Error when retrieving artist " + cr.getResponse().getStatus());
		}

		return res;
	}
	
	public Albums getArtistAlbums(String query) throws UnsupportedEncodingException {

		Albums res = null;
		ClientResource cr = null;
		String queryEncoded = null;

		try {
			queryEncoded = URLEncoder.encode(query, "utf-8");
			cr = new ClientResource("https://api.spotify.com/v1/artists/" + queryEncoded + "/albums?album_type=single,album,appears_on&market=ES");
			res = cr.get(Albums.class);
			
		} catch (ResourceException e) {
			System.err.println("Error when retrieving albums " + cr.getResponse().getStatus());
		}

		return res;
	}
	
	public AlbumGet getAlbum(String query) throws UnsupportedEncodingException {

		AlbumGet res = null;
		ClientResource cr = null;
		String queryEncoded = null;

		try {
			queryEncoded = URLEncoder.encode(query, "utf-8");
			cr = new ClientResource("https://api.spotify.com/v1/albums/" + queryEncoded + "?market=ES");
			res = cr.get(AlbumGet.class);
			
		} catch (ResourceException e) {
			System.err.println("Error when retrieving albums " + cr.getResponse().getStatus());
		}

		return res;

	}

}
