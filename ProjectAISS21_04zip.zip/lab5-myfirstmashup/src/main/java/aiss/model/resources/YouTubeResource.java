package aiss.model.resources;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.logging.Logger;

import org.restlet.resource.ClientResource;

import aiss.model.youtube.video.VideoSearch;

public class YouTubeResource {

	private static final Logger log = Logger.getLogger(YouTubeResource.class.getName());
	private static final String key = "AIzaSyCfozOooej8h8UXNtVSvZxCxG-Wf7L-VXI";
	
	public VideoSearch getVideos(String query) throws UnsupportedEncodingException {
		
		String video = URLEncoder.encode(query, "UTF-8");
	    ClientResource cr = new ClientResource("https://www.googleapis.com/youtube/v3/search?part=id&q="+video+"&type=video&key=" + key);
	    VideoSearch vs = cr.get(VideoSearch.class);
	    return vs;
		
	}
}
